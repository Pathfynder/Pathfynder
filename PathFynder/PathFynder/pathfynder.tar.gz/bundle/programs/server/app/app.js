var require = meteorInstall({"collections":{"collections.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// collections/collections.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Course = new Mongo.Collection('course');                                                                          // 1
CourseReview = new Mongo.Collection('courseReview');                                                              // 2
Internship = new Mongo.Collection('internship');                                                                  // 3
InternReview = new Mongo.Collection('internReview');                                                              // 4
ResHall = new Mongo.Collection('resHall');                                                                        // 5
ResReview = new Mongo.Collection('resReview');                                                                    // 6
Dining = new Mongo.Collection('dining');                                                                          // 7
DiningReview = new Mongo.Collection('diningReview');                                                              // 8
Club = new Mongo.Collection('club');                                                                              // 9
ClubReview = new Mongo.Collection('clubReview');                                                                  // 10
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"maybe.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/maybe.js                                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * Created by Brad on 3/1/2017.                                                                                   //
 */Accounts.config({                                                                                              //
  restrictCreationByEmailDomain: 'purdue.edu'                                                                     // 5
});                                                                                                               // 4
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/main.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Meteor = void 0;                                                                                              // 1
module.import('meteor/meteor', {                                                                                  // 1
    "Meteor": function (v) {                                                                                      // 1
        Meteor = v;                                                                                               // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
Meteor.startup(function () {                                                                                      // 3
    // code to run on server at startup                                                                           // 4
    process.env.MAIL_URL = 'smtp://allenkenobi2@sandboxe19a2b27f9c341a88a7a405dbb68cf95.mailgun.org:cookies@smtp.mailgun.org:587';
    console.log(process.env);                                                                                     // 6
                                                                                                                  //
    Accounts.urls.verifyEmail = function (token) {                                                                // 7
        return Meteor.absoluteUrl('verify-email/' + token);                                                       // 8
    };                                                                                                            // 9
                                                                                                                  //
    Accounts.emailTemplates.resetPassword.text = function (user, url) {                                           // 10
        var token = url.substring(url.lastIndexOf('/') + 1, url.length);                                          // 11
        var newUrl = Meteor.absoluteUrl('reset-password/' + token);                                               // 12
        var str = 'Hello,\n';                                                                                     // 13
        str += 'To reset your password, please click the following link...\n';                                    // 14
        str += newUrl;                                                                                            // 15
        return str;                                                                                               // 16
    };                                                                                                            // 17
                                                                                                                  //
    Accounts.emailTemplates.resetPassword.from = function () {                                                    // 18
        // Overrides value set in Accounts.emailTemplates.from when resetting passwords                           // 19
        return "PathFynder Support <no-reply@pathfynder.ltd>";                                                    // 20
    };                                                                                                            // 21
                                                                                                                  //
    Accounts.emailTemplates.verifyEmail.from = function () {                                                      // 22
        // Overrides value set in Accounts.emailTemplates.from when resetting passwords                           // 23
        return "PathFynder Support <no-reply@pathfynder.ltd>";                                                    // 24
    };                                                                                                            // 25
                                                                                                                  //
    Accounts.emailTemplates.verifyEmail.subject = function () {                                                   // 26
        return "Verification Email for PathFynder";                                                               // 27
    };                                                                                                            // 28
                                                                                                                  //
    Accounts.emailTemplates.resetPassword.subject = function () {                                                 // 29
        return "Reset Password for PathFynder";                                                                   // 30
    };                                                                                                            // 31
}); //Accounts.urls.verifyEmail = function (token) {                                                              // 33
//   return Meteor.absoluteUrl('verify-email/' + token);                                                          // 35
//}                                                                                                               // 36
//Accounts.urls.resetPassword = function(token) {                                                                 // 37
//    return Meteor.absoluteUrl('reset-password/' + token);                                                       // 38
//};                                                                                                              // 39
                                                                                                                  //
Meteor.methods({                                                                                                  // 40
    serverVerifyEmail: function (email, userId, callback) {                                                       // 41
        console.log("Email to verify:" + email + " | userId: " + userId); // this needs to be done on the server.
                                                                                                                  //
        Accounts.sendVerificationEmail(userId, email);                                                            // 44
                                                                                                                  //
        if (typeof callback !== 'undefined') {                                                                    // 45
            callback();                                                                                           // 46
        }                                                                                                         // 47
    },                                                                                                            // 48
    checkEmailVerification: function (email) {                                                                    // 49
        var found_user = Meteor.users.findOne({                                                                   // 50
            'emails.address': email                                                                               // 50
        });                                                                                                       // 50
                                                                                                                  //
        if (found_user) {                                                                                         // 51
            if (found_user.emails[0].verified == true) {                                                          // 52
                return "verified";                                                                                // 53
            } else {                                                                                              // 54
                return "unverified";                                                                              // 55
            }                                                                                                     // 56
        } else {                                                                                                  // 57
            return "notfound";                                                                                    // 58
        }                                                                                                         // 59
    }                                                                                                             // 60
});                                                                                                               // 40
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./collections/collections.js");
require("./server/maybe.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map

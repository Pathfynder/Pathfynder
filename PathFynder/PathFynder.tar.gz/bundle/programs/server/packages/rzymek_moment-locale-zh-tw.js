(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/rzymek_moment-locale-zh-tw/packages/rzymek_moment-locale-zh-tw.js                           //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/rzymek:moment-locale-zh-tw/server.js                                                 //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
global.moment = moment;                                                                          // 1
                                                                                                 // 2
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/rzymek:moment-locale-zh-tw/locale.js                                                 //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
// moment.js locale configuration                                                                // 1
// locale : traditional chinese (zh-tw)                                                          // 2
// author : Ben : https://github.com/ben-lin                                                     // 3
                                                                                                 // 4
(function (factory) {                                                                            // 5
    if (typeof define === 'function' && define.amd) {                                            // 6
        define(['moment'], factory); // AMD                                                      // 7
    } else if (typeof exports === 'object') {                                                    // 8
        module.exports = factory(require('../moment')); // Node                                  // 9
    } else {                                                                                     // 10
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global // 11
    }                                                                                            // 12
}(function (moment) {                                                                            // 13
    return moment.defineLocale('zh-tw', {                                                        // 14
        months : '一月_二月_三月_四月_五月_六月_七月_八月_九月_十月_十一月_十二月'.split('_'),                             // 15
        monthsShort : '1月_2月_3月_4月_5月_6月_7月_8月_9月_10月_11月_12月'.split('_'),                       // 16
        weekdays : '星期日_星期一_星期二_星期三_星期四_星期五_星期六'.split('_'),                                     // 17
        weekdaysShort : '週日_週一_週二_週三_週四_週五_週六'.split('_'),                                       // 18
        weekdaysMin : '日_一_二_三_四_五_六'.split('_'),                                                // 19
        longDateFormat : {                                                                       // 20
            LT : 'Ah點mm',                                                                        // 21
            LTS : 'Ah點m分s秒',                                                                     // 22
            L : 'YYYY年MMMD日',                                                                    // 23
            LL : 'YYYY年MMMD日',                                                                   // 24
            LLL : 'YYYY年MMMD日LT',                                                                // 25
            LLLL : 'YYYY年MMMD日ddddLT',                                                           // 26
            l : 'YYYY年MMMD日',                                                                    // 27
            ll : 'YYYY年MMMD日',                                                                   // 28
            lll : 'YYYY年MMMD日LT',                                                                // 29
            llll : 'YYYY年MMMD日ddddLT'                                                            // 30
        },                                                                                       // 31
        meridiemParse: /早上|上午|中午|下午|晚上/,                                                         // 32
        meridiemHour : function (hour, meridiem) {                                               // 33
            if (hour === 12) {                                                                   // 34
                hour = 0;                                                                        // 35
            }                                                                                    // 36
            if (meridiem === '早上' || meridiem === '上午') {                                        // 37
                return hour;                                                                     // 38
            } else if (meridiem === '中午') {                                                      // 39
                return hour >= 11 ? hour : hour + 12;                                            // 40
            } else if (meridiem === '下午' || meridiem === '晚上') {                                 // 41
                return hour + 12;                                                                // 42
            }                                                                                    // 43
        },                                                                                       // 44
        meridiem : function (hour, minute, isLower) {                                            // 45
            var hm = hour * 100 + minute;                                                        // 46
            if (hm < 900) {                                                                      // 47
                return '早上';                                                                     // 48
            } else if (hm < 1130) {                                                              // 49
                return '上午';                                                                     // 50
            } else if (hm < 1230) {                                                              // 51
                return '中午';                                                                     // 52
            } else if (hm < 1800) {                                                              // 53
                return '下午';                                                                     // 54
            } else {                                                                             // 55
                return '晚上';                                                                     // 56
            }                                                                                    // 57
        },                                                                                       // 58
        calendar : {                                                                             // 59
            sameDay : '[今天]LT',                                                                  // 60
            nextDay : '[明天]LT',                                                                  // 61
            nextWeek : '[下]ddddLT',                                                              // 62
            lastDay : '[昨天]LT',                                                                  // 63
            lastWeek : '[上]ddddLT',                                                              // 64
            sameElse : 'L'                                                                       // 65
        },                                                                                       // 66
        ordinalParse: /\d{1,2}(日|月|週)/,                                                          // 67
        ordinal : function (number, period) {                                                    // 68
            switch (period) {                                                                    // 69
            case 'd' :                                                                           // 70
            case 'D' :                                                                           // 71
            case 'DDD' :                                                                         // 72
                return number + '日';                                                             // 73
            case 'M' :                                                                           // 74
                return number + '月';                                                             // 75
            case 'w' :                                                                           // 76
            case 'W' :                                                                           // 77
                return number + '週';                                                             // 78
            default :                                                                            // 79
                return number;                                                                   // 80
            }                                                                                    // 81
        },                                                                                       // 82
        relativeTime : {                                                                         // 83
            future : '%s內',                                                                      // 84
            past : '%s前',                                                                        // 85
            s : '幾秒',                                                                            // 86
            m : '一分鐘',                                                                           // 87
            mm : '%d分鐘',                                                                         // 88
            h : '一小時',                                                                           // 89
            hh : '%d小時',                                                                         // 90
            d : '一天',                                                                            // 91
            dd : '%d天',                                                                          // 92
            M : '一個月',                                                                           // 93
            MM : '%d個月',                                                                         // 94
            y : '一年',                                                                            // 95
            yy : '%d年'                                                                           // 96
        }                                                                                        // 97
    });                                                                                          // 98
}));                                                                                             // 99
                                                                                                 // 100
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-zh-tw'] = {};

})();

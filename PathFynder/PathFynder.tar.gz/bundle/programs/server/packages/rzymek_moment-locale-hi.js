(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/rzymek_moment-locale-hi/packages/rzymek_moment-locale-hi.js                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/rzymek:moment-locale-hi/server.js                                                              //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
global.moment = moment;                                                                                    // 1
                                                                                                           // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/rzymek:moment-locale-hi/locale.js                                                              //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
// moment.js locale configuration                                                                          // 1
// locale : hindi (hi)                                                                                     // 2
// author : Mayank Singhal : https://github.com/mayanksinghal                                              // 3
                                                                                                           // 4
(function (factory) {                                                                                      // 5
    if (typeof define === 'function' && define.amd) {                                                      // 6
        define(['moment'], factory); // AMD                                                                // 7
    } else if (typeof exports === 'object') {                                                              // 8
        module.exports = factory(require('../moment')); // Node                                            // 9
    } else {                                                                                               // 10
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global           // 11
    }                                                                                                      // 12
}(function (moment) {                                                                                      // 13
    var symbolMap = {                                                                                      // 14
        '1': '१',                                                                                          // 15
        '2': '२',                                                                                          // 16
        '3': '३',                                                                                          // 17
        '4': '४',                                                                                          // 18
        '5': '५',                                                                                          // 19
        '6': '६',                                                                                          // 20
        '7': '७',                                                                                          // 21
        '8': '८',                                                                                          // 22
        '9': '९',                                                                                          // 23
        '0': '०'                                                                                           // 24
    },                                                                                                     // 25
    numberMap = {                                                                                          // 26
        '१': '1',                                                                                          // 27
        '२': '2',                                                                                          // 28
        '३': '3',                                                                                          // 29
        '४': '4',                                                                                          // 30
        '५': '5',                                                                                          // 31
        '६': '6',                                                                                          // 32
        '७': '7',                                                                                          // 33
        '८': '8',                                                                                          // 34
        '९': '9',                                                                                          // 35
        '०': '0'                                                                                           // 36
    };                                                                                                     // 37
                                                                                                           // 38
    return moment.defineLocale('hi', {                                                                     // 39
        months : 'जनवरी_फ़रवरी_मार्च_अप्रैल_मई_जून_जुलाई_अगस्त_सितम्बर_अक्टूबर_नवम्बर_दिसम्बर'.split('_'), // 40
        monthsShort : 'जन._फ़र._मार्च_अप्रै._मई_जून_जुल._अग._सित._अक्टू._नव._दिस.'.split('_'),             // 41
        weekdays : 'रविवार_सोमवार_मंगलवार_बुधवार_गुरूवार_शुक्रवार_शनिवार'.split('_'),                      // 42
        weekdaysShort : 'रवि_सोम_मंगल_बुध_गुरू_शुक्र_शनि'.split('_'),                                      // 43
        weekdaysMin : 'र_सो_मं_बु_गु_शु_श'.split('_'),                                                     // 44
        longDateFormat : {                                                                                 // 45
            LT : 'A h:mm बजे',                                                                             // 46
            LTS : 'A h:mm:ss बजे',                                                                         // 47
            L : 'DD/MM/YYYY',                                                                              // 48
            LL : 'D MMMM YYYY',                                                                            // 49
            LLL : 'D MMMM YYYY, LT',                                                                       // 50
            LLLL : 'dddd, D MMMM YYYY, LT'                                                                 // 51
        },                                                                                                 // 52
        calendar : {                                                                                       // 53
            sameDay : '[आज] LT',                                                                           // 54
            nextDay : '[कल] LT',                                                                           // 55
            nextWeek : 'dddd, LT',                                                                         // 56
            lastDay : '[कल] LT',                                                                           // 57
            lastWeek : '[पिछले] dddd, LT',                                                                 // 58
            sameElse : 'L'                                                                                 // 59
        },                                                                                                 // 60
        relativeTime : {                                                                                   // 61
            future : '%s में',                                                                             // 62
            past : '%s पहले',                                                                              // 63
            s : 'कुछ ही क्षण',                                                                             // 64
            m : 'एक मिनट',                                                                                 // 65
            mm : '%d मिनट',                                                                                // 66
            h : 'एक घंटा',                                                                                 // 67
            hh : '%d घंटे',                                                                                // 68
            d : 'एक दिन',                                                                                  // 69
            dd : '%d दिन',                                                                                 // 70
            M : 'एक महीने',                                                                                // 71
            MM : '%d महीने',                                                                               // 72
            y : 'एक वर्ष',                                                                                 // 73
            yy : '%d वर्ष'                                                                                 // 74
        },                                                                                                 // 75
        preparse: function (string) {                                                                      // 76
            return string.replace(/[१२३४५६७८९०]/g, function (match) {                                      // 77
                return numberMap[match];                                                                   // 78
            });                                                                                            // 79
        },                                                                                                 // 80
        postformat: function (string) {                                                                    // 81
            return string.replace(/\d/g, function (match) {                                                // 82
                return symbolMap[match];                                                                   // 83
            });                                                                                            // 84
        },                                                                                                 // 85
        // Hindi notation for meridiems are quite fuzzy in practice. While there exists                    // 86
        // a rigid notion of a 'Pahar' it is not used as rigidly in modern Hindi.                          // 87
        meridiemParse: /रात|सुबह|दोपहर|शाम/,                                                               // 88
        meridiemHour : function (hour, meridiem) {                                                         // 89
            if (hour === 12) {                                                                             // 90
                hour = 0;                                                                                  // 91
            }                                                                                              // 92
            if (meridiem === 'रात') {                                                                      // 93
                return hour < 4 ? hour : hour + 12;                                                        // 94
            } else if (meridiem === 'सुबह') {                                                              // 95
                return hour;                                                                               // 96
            } else if (meridiem === 'दोपहर') {                                                             // 97
                return hour >= 10 ? hour : hour + 12;                                                      // 98
            } else if (meridiem === 'शाम') {                                                               // 99
                return hour + 12;                                                                          // 100
            }                                                                                              // 101
        },                                                                                                 // 102
        meridiem : function (hour, minute, isLower) {                                                      // 103
            if (hour < 4) {                                                                                // 104
                return 'रात';                                                                              // 105
            } else if (hour < 10) {                                                                        // 106
                return 'सुबह';                                                                             // 107
            } else if (hour < 17) {                                                                        // 108
                return 'दोपहर';                                                                            // 109
            } else if (hour < 20) {                                                                        // 110
                return 'शाम';                                                                              // 111
            } else {                                                                                       // 112
                return 'रात';                                                                              // 113
            }                                                                                              // 114
        },                                                                                                 // 115
        week : {                                                                                           // 116
            dow : 0, // Sunday is the first day of the week.                                               // 117
            doy : 6  // The week that contains Jan 1st is the first week of the year.                      // 118
        }                                                                                                  // 119
    });                                                                                                    // 120
}));                                                                                                       // 121
                                                                                                           // 122
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-hi'] = {};

})();

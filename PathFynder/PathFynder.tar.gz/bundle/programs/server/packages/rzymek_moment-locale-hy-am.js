(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/rzymek_moment-locale-hy-am/packages/rzymek_moment-locale-hy-am.js                             //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// packages/rzymek:moment-locale-hy-am/server.js                                                   //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
global.moment = moment;                                                                            // 1
                                                                                                   // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// packages/rzymek:moment-locale-hy-am/locale.js                                                   //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
// moment.js locale configuration                                                                  // 1
// locale : Armenian (hy-am)                                                                       // 2
// author : Armendarabyan : https://github.com/armendarabyan                                       // 3
                                                                                                   // 4
(function (factory) {                                                                              // 5
    if (typeof define === 'function' && define.amd) {                                              // 6
        define(['moment'], factory); // AMD                                                        // 7
    } else if (typeof exports === 'object') {                                                      // 8
        module.exports = factory(require('../moment')); // Node                                    // 9
    } else {                                                                                       // 10
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global   // 11
    }                                                                                              // 12
}(function (moment) {                                                                              // 13
    function monthsCaseReplace(m, format) {                                                        // 14
        var months = {                                                                             // 15
            'nominative': 'հունվար_փետրվար_մարտ_ապրիլ_մայիս_հունիս_հուլիս_օգոստոս_սեպտեմբեր_հոկտեմբեր_նոյեմբեր_դեկտեմբեր'.split('_'),
            'accusative': 'հունվարի_փետրվարի_մարտի_ապրիլի_մայիսի_հունիսի_հուլիսի_օգոստոսի_սեպտեմբերի_հոկտեմբերի_նոյեմբերի_դեկտեմբերի'.split('_')
        },                                                                                         // 18
                                                                                                   // 19
        nounCase = (/D[oD]?(\[[^\[\]]*\]|\s+)+MMMM?/).test(format) ?                               // 20
            'accusative' :                                                                         // 21
            'nominative';                                                                          // 22
                                                                                                   // 23
        return months[nounCase][m.month()];                                                        // 24
    }                                                                                              // 25
                                                                                                   // 26
    function monthsShortCaseReplace(m, format) {                                                   // 27
        var monthsShort = 'հնվ_փտր_մրտ_ապր_մյս_հնս_հլս_օգս_սպտ_հկտ_նմբ_դկտ'.split('_');            // 28
                                                                                                   // 29
        return monthsShort[m.month()];                                                             // 30
    }                                                                                              // 31
                                                                                                   // 32
    function weekdaysCaseReplace(m, format) {                                                      // 33
        var weekdays = 'կիրակի_երկուշաբթի_երեքշաբթի_չորեքշաբթի_հինգշաբթի_ուրբաթ_շաբաթ'.split('_'); // 34
                                                                                                   // 35
        return weekdays[m.day()];                                                                  // 36
    }                                                                                              // 37
                                                                                                   // 38
    return moment.defineLocale('hy-am', {                                                          // 39
        months : monthsCaseReplace,                                                                // 40
        monthsShort : monthsShortCaseReplace,                                                      // 41
        weekdays : weekdaysCaseReplace,                                                            // 42
        weekdaysShort : 'կրկ_երկ_երք_չրք_հնգ_ուրբ_շբթ'.split('_'),                                 // 43
        weekdaysMin : 'կրկ_երկ_երք_չրք_հնգ_ուրբ_շբթ'.split('_'),                                   // 44
        longDateFormat : {                                                                         // 45
            LT : 'HH:mm',                                                                          // 46
            LTS : 'LT:ss',                                                                         // 47
            L : 'DD.MM.YYYY',                                                                      // 48
            LL : 'D MMMM YYYY թ.',                                                                 // 49
            LLL : 'D MMMM YYYY թ., LT',                                                            // 50
            LLLL : 'dddd, D MMMM YYYY թ., LT'                                                      // 51
        },                                                                                         // 52
        calendar : {                                                                               // 53
            sameDay: '[այսօր] LT',                                                                 // 54
            nextDay: '[վաղը] LT',                                                                  // 55
            lastDay: '[երեկ] LT',                                                                  // 56
            nextWeek: function () {                                                                // 57
                return 'dddd [օրը ժամը] LT';                                                       // 58
            },                                                                                     // 59
            lastWeek: function () {                                                                // 60
                return '[անցած] dddd [օրը ժամը] LT';                                               // 61
            },                                                                                     // 62
            sameElse: 'L'                                                                          // 63
        },                                                                                         // 64
        relativeTime : {                                                                           // 65
            future : '%s հետո',                                                                    // 66
            past : '%s առաջ',                                                                      // 67
            s : 'մի քանի վայրկյան',                                                                // 68
            m : 'րոպե',                                                                            // 69
            mm : '%d րոպե',                                                                        // 70
            h : 'ժամ',                                                                             // 71
            hh : '%d ժամ',                                                                         // 72
            d : 'օր',                                                                              // 73
            dd : '%d օր',                                                                          // 74
            M : 'ամիս',                                                                            // 75
            MM : '%d ամիս',                                                                        // 76
            y : 'տարի',                                                                            // 77
            yy : '%d տարի'                                                                         // 78
        },                                                                                         // 79
                                                                                                   // 80
        meridiemParse: /գիշերվա|առավոտվա|ցերեկվա|երեկոյան/,                                        // 81
        isPM: function (input) {                                                                   // 82
            return /^(ցերեկվա|երեկոյան)$/.test(input);                                             // 83
        },                                                                                         // 84
        meridiem : function (hour) {                                                               // 85
            if (hour < 4) {                                                                        // 86
                return 'գիշերվա';                                                                  // 87
            } else if (hour < 12) {                                                                // 88
                return 'առավոտվա';                                                                 // 89
            } else if (hour < 17) {                                                                // 90
                return 'ցերեկվա';                                                                  // 91
            } else {                                                                               // 92
                return 'երեկոյան';                                                                 // 93
            }                                                                                      // 94
        },                                                                                         // 95
                                                                                                   // 96
        ordinalParse: /\d{1,2}|\d{1,2}-(ին|րդ)/,                                                   // 97
        ordinal: function (number, period) {                                                       // 98
            switch (period) {                                                                      // 99
            case 'DDD':                                                                            // 100
            case 'w':                                                                              // 101
            case 'W':                                                                              // 102
            case 'DDDo':                                                                           // 103
                if (number === 1) {                                                                // 104
                    return number + '-ին';                                                         // 105
                }                                                                                  // 106
                return number + '-րդ';                                                             // 107
            default:                                                                               // 108
                return number;                                                                     // 109
            }                                                                                      // 110
        },                                                                                         // 111
                                                                                                   // 112
        week : {                                                                                   // 113
            dow : 1, // Monday is the first day of the week.                                       // 114
            doy : 7  // The week that contains Jan 1st is the first week of the year.              // 115
        }                                                                                          // 116
    });                                                                                            // 117
}));                                                                                               // 118
                                                                                                   // 119
/////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-hy-am'] = {};

})();

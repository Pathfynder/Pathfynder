(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rzymek_moment-locale-ru/packages/rzymek_moment-locale-ru.js                                      //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/rzymek:moment-locale-ru/server.js                                                         //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
global.moment = moment;                                                                               // 1
                                                                                                      // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/rzymek:moment-locale-ru/locale.js                                                         //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
// moment.js locale configuration                                                                     // 1
// locale : russian (ru)                                                                              // 2
// author : Viktorminator : https://github.com/Viktorminator                                          // 3
// Author : Menelion Elensúle : https://github.com/Oire                                               // 4
                                                                                                      // 5
(function (factory) {                                                                                 // 6
    if (typeof define === 'function' && define.amd) {                                                 // 7
        define(['moment'], factory); // AMD                                                           // 8
    } else if (typeof exports === 'object') {                                                         // 9
        module.exports = factory(require('../moment')); // Node                                       // 10
    } else {                                                                                          // 11
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global      // 12
    }                                                                                                 // 13
}(function (moment) {                                                                                 // 14
    function plural(word, num) {                                                                      // 15
        var forms = word.split('_');                                                                  // 16
        return num % 10 === 1 && num % 100 !== 11 ? forms[0] : (num % 10 >= 2 && num % 10 <= 4 && (num % 100 < 10 || num % 100 >= 20) ? forms[1] : forms[2]);
    }                                                                                                 // 18
                                                                                                      // 19
    function relativeTimeWithPlural(number, withoutSuffix, key) {                                     // 20
        var format = {                                                                                // 21
            'mm': withoutSuffix ? 'минута_минуты_минут' : 'минуту_минуты_минут',                      // 22
            'hh': 'час_часа_часов',                                                                   // 23
            'dd': 'день_дня_дней',                                                                    // 24
            'MM': 'месяц_месяца_месяцев',                                                             // 25
            'yy': 'год_года_лет'                                                                      // 26
        };                                                                                            // 27
        if (key === 'm') {                                                                            // 28
            return withoutSuffix ? 'минута' : 'минуту';                                               // 29
        }                                                                                             // 30
        else {                                                                                        // 31
            return number + ' ' + plural(format[key], +number);                                       // 32
        }                                                                                             // 33
    }                                                                                                 // 34
                                                                                                      // 35
    function monthsCaseReplace(m, format) {                                                           // 36
        var months = {                                                                                // 37
            'nominative': 'январь_февраль_март_апрель_май_июнь_июль_август_сентябрь_октябрь_ноябрь_декабрь'.split('_'),
            'accusative': 'января_февраля_марта_апреля_мая_июня_июля_августа_сентября_октября_ноября_декабря'.split('_')
        },                                                                                            // 40
                                                                                                      // 41
        nounCase = (/D[oD]?(\[[^\[\]]*\]|\s+)+MMMM?/).test(format) ?                                  // 42
            'accusative' :                                                                            // 43
            'nominative';                                                                             // 44
                                                                                                      // 45
        return months[nounCase][m.month()];                                                           // 46
    }                                                                                                 // 47
                                                                                                      // 48
    function monthsShortCaseReplace(m, format) {                                                      // 49
        var monthsShort = {                                                                           // 50
            'nominative': 'янв_фев_март_апр_май_июнь_июль_авг_сен_окт_ноя_дек'.split('_'),            // 51
            'accusative': 'янв_фев_мар_апр_мая_июня_июля_авг_сен_окт_ноя_дек'.split('_')              // 52
        },                                                                                            // 53
                                                                                                      // 54
        nounCase = (/D[oD]?(\[[^\[\]]*\]|\s+)+MMMM?/).test(format) ?                                  // 55
            'accusative' :                                                                            // 56
            'nominative';                                                                             // 57
                                                                                                      // 58
        return monthsShort[nounCase][m.month()];                                                      // 59
    }                                                                                                 // 60
                                                                                                      // 61
    function weekdaysCaseReplace(m, format) {                                                         // 62
        var weekdays = {                                                                              // 63
            'nominative': 'воскресенье_понедельник_вторник_среда_четверг_пятница_суббота'.split('_'), // 64
            'accusative': 'воскресенье_понедельник_вторник_среду_четверг_пятницу_субботу'.split('_')  // 65
        },                                                                                            // 66
                                                                                                      // 67
        nounCase = (/\[ ?[Вв] ?(?:прошлую|следующую|эту)? ?\] ?dddd/).test(format) ?                  // 68
            'accusative' :                                                                            // 69
            'nominative';                                                                             // 70
                                                                                                      // 71
        return weekdays[nounCase][m.day()];                                                           // 72
    }                                                                                                 // 73
                                                                                                      // 74
    return moment.defineLocale('ru', {                                                                // 75
        months : monthsCaseReplace,                                                                   // 76
        monthsShort : monthsShortCaseReplace,                                                         // 77
        weekdays : weekdaysCaseReplace,                                                               // 78
        weekdaysShort : 'вс_пн_вт_ср_чт_пт_сб'.split('_'),                                            // 79
        weekdaysMin : 'вс_пн_вт_ср_чт_пт_сб'.split('_'),                                              // 80
        monthsParse : [/^янв/i, /^фев/i, /^мар/i, /^апр/i, /^ма[й|я]/i, /^июн/i, /^июл/i, /^авг/i, /^сен/i, /^окт/i, /^ноя/i, /^дек/i],
        longDateFormat : {                                                                            // 82
            LT : 'HH:mm',                                                                             // 83
            LTS : 'LT:ss',                                                                            // 84
            L : 'DD.MM.YYYY',                                                                         // 85
            LL : 'D MMMM YYYY г.',                                                                    // 86
            LLL : 'D MMMM YYYY г., LT',                                                               // 87
            LLLL : 'dddd, D MMMM YYYY г., LT'                                                         // 88
        },                                                                                            // 89
        calendar : {                                                                                  // 90
            sameDay: '[Сегодня в] LT',                                                                // 91
            nextDay: '[Завтра в] LT',                                                                 // 92
            lastDay: '[Вчера в] LT',                                                                  // 93
            nextWeek: function () {                                                                   // 94
                return this.day() === 2 ? '[Во] dddd [в] LT' : '[В] dddd [в] LT';                     // 95
            },                                                                                        // 96
            lastWeek: function (now) {                                                                // 97
                if (now.week() !== this.week()) {                                                     // 98
                    switch (this.day()) {                                                             // 99
                    case 0:                                                                           // 100
                        return '[В прошлое] dddd [в] LT';                                             // 101
                    case 1:                                                                           // 102
                    case 2:                                                                           // 103
                    case 4:                                                                           // 104
                        return '[В прошлый] dddd [в] LT';                                             // 105
                    case 3:                                                                           // 106
                    case 5:                                                                           // 107
                    case 6:                                                                           // 108
                        return '[В прошлую] dddd [в] LT';                                             // 109
                    }                                                                                 // 110
                } else {                                                                              // 111
                    if (this.day() === 2) {                                                           // 112
                        return '[Во] dddd [в] LT';                                                    // 113
                    } else {                                                                          // 114
                        return '[В] dddd [в] LT';                                                     // 115
                    }                                                                                 // 116
                }                                                                                     // 117
            },                                                                                        // 118
            sameElse: 'L'                                                                             // 119
        },                                                                                            // 120
        relativeTime : {                                                                              // 121
            future : 'через %s',                                                                      // 122
            past : '%s назад',                                                                        // 123
            s : 'несколько секунд',                                                                   // 124
            m : relativeTimeWithPlural,                                                               // 125
            mm : relativeTimeWithPlural,                                                              // 126
            h : 'час',                                                                                // 127
            hh : relativeTimeWithPlural,                                                              // 128
            d : 'день',                                                                               // 129
            dd : relativeTimeWithPlural,                                                              // 130
            M : 'месяц',                                                                              // 131
            MM : relativeTimeWithPlural,                                                              // 132
            y : 'год',                                                                                // 133
            yy : relativeTimeWithPlural                                                               // 134
        },                                                                                            // 135
                                                                                                      // 136
        meridiemParse: /ночи|утра|дня|вечера/i,                                                       // 137
        isPM : function (input) {                                                                     // 138
            return /^(дня|вечера)$/.test(input);                                                      // 139
        },                                                                                            // 140
                                                                                                      // 141
        meridiem : function (hour, minute, isLower) {                                                 // 142
            if (hour < 4) {                                                                           // 143
                return 'ночи';                                                                        // 144
            } else if (hour < 12) {                                                                   // 145
                return 'утра';                                                                        // 146
            } else if (hour < 17) {                                                                   // 147
                return 'дня';                                                                         // 148
            } else {                                                                                  // 149
                return 'вечера';                                                                      // 150
            }                                                                                         // 151
        },                                                                                            // 152
                                                                                                      // 153
        ordinalParse: /\d{1,2}-(й|го|я)/,                                                             // 154
        ordinal: function (number, period) {                                                          // 155
            switch (period) {                                                                         // 156
            case 'M':                                                                                 // 157
            case 'd':                                                                                 // 158
            case 'DDD':                                                                               // 159
                return number + '-й';                                                                 // 160
            case 'D':                                                                                 // 161
                return number + '-го';                                                                // 162
            case 'w':                                                                                 // 163
            case 'W':                                                                                 // 164
                return number + '-я';                                                                 // 165
            default:                                                                                  // 166
                return number;                                                                        // 167
            }                                                                                         // 168
        },                                                                                            // 169
                                                                                                      // 170
        week : {                                                                                      // 171
            dow : 1, // Monday is the first day of the week.                                          // 172
            doy : 7  // The week that contains Jan 1st is the first week of the year.                 // 173
        }                                                                                             // 174
    });                                                                                               // 175
}));                                                                                                  // 176
                                                                                                      // 177
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-ru'] = {};

})();

(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/rzymek_moment-locale-fa/packages/rzymek_moment-locale-fa.js                                          //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/rzymek:moment-locale-fa/server.js                                                             //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
global.moment = moment;                                                                                   // 1
                                                                                                          // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/rzymek:moment-locale-fa/locale.js                                                             //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
// moment.js locale configuration                                                                         // 1
// locale : Persian (fa)                                                                                  // 2
// author : Ebrahim Byagowi : https://github.com/ebraminio                                                // 3
                                                                                                          // 4
(function (factory) {                                                                                     // 5
    if (typeof define === 'function' && define.amd) {                                                     // 6
        define(['moment'], factory); // AMD                                                               // 7
    } else if (typeof exports === 'object') {                                                             // 8
        module.exports = factory(require('../moment')); // Node                                           // 9
    } else {                                                                                              // 10
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global          // 11
    }                                                                                                     // 12
}(function (moment) {                                                                                     // 13
    var symbolMap = {                                                                                     // 14
        '1': '۱',                                                                                         // 15
        '2': '۲',                                                                                         // 16
        '3': '۳',                                                                                         // 17
        '4': '۴',                                                                                         // 18
        '5': '۵',                                                                                         // 19
        '6': '۶',                                                                                         // 20
        '7': '۷',                                                                                         // 21
        '8': '۸',                                                                                         // 22
        '9': '۹',                                                                                         // 23
        '0': '۰'                                                                                          // 24
    }, numberMap = {                                                                                      // 25
        '۱': '1',                                                                                         // 26
        '۲': '2',                                                                                         // 27
        '۳': '3',                                                                                         // 28
        '۴': '4',                                                                                         // 29
        '۵': '5',                                                                                         // 30
        '۶': '6',                                                                                         // 31
        '۷': '7',                                                                                         // 32
        '۸': '8',                                                                                         // 33
        '۹': '9',                                                                                         // 34
        '۰': '0'                                                                                          // 35
    };                                                                                                    // 36
                                                                                                          // 37
    return moment.defineLocale('fa', {                                                                    // 38
        months : 'ژانویه_فوریه_مارس_آوریل_مه_ژوئن_ژوئیه_اوت_سپتامبر_اکتبر_نوامبر_دسامبر'.split('_'),      // 39
        monthsShort : 'ژانویه_فوریه_مارس_آوریل_مه_ژوئن_ژوئیه_اوت_سپتامبر_اکتبر_نوامبر_دسامبر'.split('_'), // 40
        weekdays : 'یک\u200cشنبه_دوشنبه_سه\u200cشنبه_چهارشنبه_پنج\u200cشنبه_جمعه_شنبه'.split('_'),        // 41
        weekdaysShort : 'یک\u200cشنبه_دوشنبه_سه\u200cشنبه_چهارشنبه_پنج\u200cشنبه_جمعه_شنبه'.split('_'),   // 42
        weekdaysMin : 'ی_د_س_چ_پ_ج_ش'.split('_'),                                                         // 43
        longDateFormat : {                                                                                // 44
            LT : 'HH:mm',                                                                                 // 45
            LTS : 'LT:ss',                                                                                // 46
            L : 'DD/MM/YYYY',                                                                             // 47
            LL : 'D MMMM YYYY',                                                                           // 48
            LLL : 'D MMMM YYYY LT',                                                                       // 49
            LLLL : 'dddd, D MMMM YYYY LT'                                                                 // 50
        },                                                                                                // 51
        meridiemParse: /قبل از ظهر|بعد از ظهر/,                                                           // 52
        isPM: function (input) {                                                                          // 53
            return /بعد از ظهر/.test(input);                                                              // 54
        },                                                                                                // 55
        meridiem : function (hour, minute, isLower) {                                                     // 56
            if (hour < 12) {                                                                              // 57
                return 'قبل از ظهر';                                                                      // 58
            } else {                                                                                      // 59
                return 'بعد از ظهر';                                                                      // 60
            }                                                                                             // 61
        },                                                                                                // 62
        calendar : {                                                                                      // 63
            sameDay : '[امروز ساعت] LT',                                                                  // 64
            nextDay : '[فردا ساعت] LT',                                                                   // 65
            nextWeek : 'dddd [ساعت] LT',                                                                  // 66
            lastDay : '[دیروز ساعت] LT',                                                                  // 67
            lastWeek : 'dddd [پیش] [ساعت] LT',                                                            // 68
            sameElse : 'L'                                                                                // 69
        },                                                                                                // 70
        relativeTime : {                                                                                  // 71
            future : 'در %s',                                                                             // 72
            past : '%s پیش',                                                                              // 73
            s : 'چندین ثانیه',                                                                            // 74
            m : 'یک دقیقه',                                                                               // 75
            mm : '%d دقیقه',                                                                              // 76
            h : 'یک ساعت',                                                                                // 77
            hh : '%d ساعت',                                                                               // 78
            d : 'یک روز',                                                                                 // 79
            dd : '%d روز',                                                                                // 80
            M : 'یک ماه',                                                                                 // 81
            MM : '%d ماه',                                                                                // 82
            y : 'یک سال',                                                                                 // 83
            yy : '%d سال'                                                                                 // 84
        },                                                                                                // 85
        preparse: function (string) {                                                                     // 86
            return string.replace(/[۰-۹]/g, function (match) {                                            // 87
                return numberMap[match];                                                                  // 88
            }).replace(/،/g, ',');                                                                        // 89
        },                                                                                                // 90
        postformat: function (string) {                                                                   // 91
            return string.replace(/\d/g, function (match) {                                               // 92
                return symbolMap[match];                                                                  // 93
            }).replace(/,/g, '،');                                                                        // 94
        },                                                                                                // 95
        ordinalParse: /\d{1,2}م/,                                                                         // 96
        ordinal : '%dم',                                                                                  // 97
        week : {                                                                                          // 98
            dow : 6, // Saturday is the first day of the week.                                            // 99
            doy : 12 // The week that contains Jan 1st is the first week of the year.                     // 100
        }                                                                                                 // 101
    });                                                                                                   // 102
}));                                                                                                      // 103
                                                                                                          // 104
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-fa'] = {};

})();

(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/rzymek_moment-locale-fi/packages/rzymek_moment-locale-fi.js                                          //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/rzymek:moment-locale-fi/server.js                                                             //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
global.moment = moment;                                                                                   // 1
                                                                                                          // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                        //
// packages/rzymek:moment-locale-fi/locale.js                                                             //
//                                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                          //
// moment.js locale configuration                                                                         // 1
// locale : finnish (fi)                                                                                  // 2
// author : Tarmo Aidantausta : https://github.com/bleadof                                                // 3
                                                                                                          // 4
(function (factory) {                                                                                     // 5
    if (typeof define === 'function' && define.amd) {                                                     // 6
        define(['moment'], factory); // AMD                                                               // 7
    } else if (typeof exports === 'object') {                                                             // 8
        module.exports = factory(require('../moment')); // Node                                           // 9
    } else {                                                                                              // 10
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global          // 11
    }                                                                                                     // 12
}(function (moment) {                                                                                     // 13
    var numbersPast = 'nolla yksi kaksi kolme neljä viisi kuusi seitsemän kahdeksan yhdeksän'.split(' '), // 14
        numbersFuture = [                                                                                 // 15
            'nolla', 'yhden', 'kahden', 'kolmen', 'neljän', 'viiden', 'kuuden',                           // 16
            numbersPast[7], numbersPast[8], numbersPast[9]                                                // 17
        ];                                                                                                // 18
                                                                                                          // 19
    function translate(number, withoutSuffix, key, isFuture) {                                            // 20
        var result = '';                                                                                  // 21
        switch (key) {                                                                                    // 22
        case 's':                                                                                         // 23
            return isFuture ? 'muutaman sekunnin' : 'muutama sekunti';                                    // 24
        case 'm':                                                                                         // 25
            return isFuture ? 'minuutin' : 'minuutti';                                                    // 26
        case 'mm':                                                                                        // 27
            result = isFuture ? 'minuutin' : 'minuuttia';                                                 // 28
            break;                                                                                        // 29
        case 'h':                                                                                         // 30
            return isFuture ? 'tunnin' : 'tunti';                                                         // 31
        case 'hh':                                                                                        // 32
            result = isFuture ? 'tunnin' : 'tuntia';                                                      // 33
            break;                                                                                        // 34
        case 'd':                                                                                         // 35
            return isFuture ? 'päivän' : 'päivä';                                                         // 36
        case 'dd':                                                                                        // 37
            result = isFuture ? 'päivän' : 'päivää';                                                      // 38
            break;                                                                                        // 39
        case 'M':                                                                                         // 40
            return isFuture ? 'kuukauden' : 'kuukausi';                                                   // 41
        case 'MM':                                                                                        // 42
            result = isFuture ? 'kuukauden' : 'kuukautta';                                                // 43
            break;                                                                                        // 44
        case 'y':                                                                                         // 45
            return isFuture ? 'vuoden' : 'vuosi';                                                         // 46
        case 'yy':                                                                                        // 47
            result = isFuture ? 'vuoden' : 'vuotta';                                                      // 48
            break;                                                                                        // 49
        }                                                                                                 // 50
        result = verbalNumber(number, isFuture) + ' ' + result;                                           // 51
        return result;                                                                                    // 52
    }                                                                                                     // 53
                                                                                                          // 54
    function verbalNumber(number, isFuture) {                                                             // 55
        return number < 10 ? (isFuture ? numbersFuture[number] : numbersPast[number]) : number;           // 56
    }                                                                                                     // 57
                                                                                                          // 58
    return moment.defineLocale('fi', {                                                                    // 59
        months : 'tammikuu_helmikuu_maaliskuu_huhtikuu_toukokuu_kesäkuu_heinäkuu_elokuu_syyskuu_lokakuu_marraskuu_joulukuu'.split('_'),
        monthsShort : 'tammi_helmi_maalis_huhti_touko_kesä_heinä_elo_syys_loka_marras_joulu'.split('_'),  // 61
        weekdays : 'sunnuntai_maanantai_tiistai_keskiviikko_torstai_perjantai_lauantai'.split('_'),       // 62
        weekdaysShort : 'su_ma_ti_ke_to_pe_la'.split('_'),                                                // 63
        weekdaysMin : 'su_ma_ti_ke_to_pe_la'.split('_'),                                                  // 64
        longDateFormat : {                                                                                // 65
            LT : 'HH.mm',                                                                                 // 66
            LTS : 'HH.mm.ss',                                                                             // 67
            L : 'DD.MM.YYYY',                                                                             // 68
            LL : 'Do MMMM[ta] YYYY',                                                                      // 69
            LLL : 'Do MMMM[ta] YYYY, [klo] LT',                                                           // 70
            LLLL : 'dddd, Do MMMM[ta] YYYY, [klo] LT',                                                    // 71
            l : 'D.M.YYYY',                                                                               // 72
            ll : 'Do MMM YYYY',                                                                           // 73
            lll : 'Do MMM YYYY, [klo] LT',                                                                // 74
            llll : 'ddd, Do MMM YYYY, [klo] LT'                                                           // 75
        },                                                                                                // 76
        calendar : {                                                                                      // 77
            sameDay : '[tänään] [klo] LT',                                                                // 78
            nextDay : '[huomenna] [klo] LT',                                                              // 79
            nextWeek : 'dddd [klo] LT',                                                                   // 80
            lastDay : '[eilen] [klo] LT',                                                                 // 81
            lastWeek : '[viime] dddd[na] [klo] LT',                                                       // 82
            sameElse : 'L'                                                                                // 83
        },                                                                                                // 84
        relativeTime : {                                                                                  // 85
            future : '%s päästä',                                                                         // 86
            past : '%s sitten',                                                                           // 87
            s : translate,                                                                                // 88
            m : translate,                                                                                // 89
            mm : translate,                                                                               // 90
            h : translate,                                                                                // 91
            hh : translate,                                                                               // 92
            d : translate,                                                                                // 93
            dd : translate,                                                                               // 94
            M : translate,                                                                                // 95
            MM : translate,                                                                               // 96
            y : translate,                                                                                // 97
            yy : translate                                                                                // 98
        },                                                                                                // 99
        ordinalParse: /\d{1,2}\./,                                                                        // 100
        ordinal : '%d.',                                                                                  // 101
        week : {                                                                                          // 102
            dow : 1, // Monday is the first day of the week.                                              // 103
            doy : 4  // The week that contains Jan 4th is the first week of the year.                     // 104
        }                                                                                                 // 105
    });                                                                                                   // 106
}));                                                                                                      // 107
                                                                                                          // 108
////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-fi'] = {};

})();

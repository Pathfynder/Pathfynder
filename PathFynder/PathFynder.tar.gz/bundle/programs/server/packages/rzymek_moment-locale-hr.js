(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/rzymek_moment-locale-hr/packages/rzymek_moment-locale-hr.js                                 //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/rzymek:moment-locale-hr/server.js                                                    //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
global.moment = moment;                                                                          // 1
                                                                                                 // 2
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/rzymek:moment-locale-hr/locale.js                                                    //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
// moment.js locale configuration                                                                // 1
// locale : hrvatski (hr)                                                                        // 2
// author : Bojan Marković : https://github.com/bmarkovic                                        // 3
                                                                                                 // 4
// based on (sl) translation by Robert Sedovšek                                                  // 5
                                                                                                 // 6
(function (factory) {                                                                            // 7
    if (typeof define === 'function' && define.amd) {                                            // 8
        define(['moment'], factory); // AMD                                                      // 9
    } else if (typeof exports === 'object') {                                                    // 10
        module.exports = factory(require('../moment')); // Node                                  // 11
    } else {                                                                                     // 12
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global // 13
    }                                                                                            // 14
}(function (moment) {                                                                            // 15
    function translate(number, withoutSuffix, key) {                                             // 16
        var result = number + ' ';                                                               // 17
        switch (key) {                                                                           // 18
        case 'm':                                                                                // 19
            return withoutSuffix ? 'jedna minuta' : 'jedne minute';                              // 20
        case 'mm':                                                                               // 21
            if (number === 1) {                                                                  // 22
                result += 'minuta';                                                              // 23
            } else if (number === 2 || number === 3 || number === 4) {                           // 24
                result += 'minute';                                                              // 25
            } else {                                                                             // 26
                result += 'minuta';                                                              // 27
            }                                                                                    // 28
            return result;                                                                       // 29
        case 'h':                                                                                // 30
            return withoutSuffix ? 'jedan sat' : 'jednog sata';                                  // 31
        case 'hh':                                                                               // 32
            if (number === 1) {                                                                  // 33
                result += 'sat';                                                                 // 34
            } else if (number === 2 || number === 3 || number === 4) {                           // 35
                result += 'sata';                                                                // 36
            } else {                                                                             // 37
                result += 'sati';                                                                // 38
            }                                                                                    // 39
            return result;                                                                       // 40
        case 'dd':                                                                               // 41
            if (number === 1) {                                                                  // 42
                result += 'dan';                                                                 // 43
            } else {                                                                             // 44
                result += 'dana';                                                                // 45
            }                                                                                    // 46
            return result;                                                                       // 47
        case 'MM':                                                                               // 48
            if (number === 1) {                                                                  // 49
                result += 'mjesec';                                                              // 50
            } else if (number === 2 || number === 3 || number === 4) {                           // 51
                result += 'mjeseca';                                                             // 52
            } else {                                                                             // 53
                result += 'mjeseci';                                                             // 54
            }                                                                                    // 55
            return result;                                                                       // 56
        case 'yy':                                                                               // 57
            if (number === 1) {                                                                  // 58
                result += 'godina';                                                              // 59
            } else if (number === 2 || number === 3 || number === 4) {                           // 60
                result += 'godine';                                                              // 61
            } else {                                                                             // 62
                result += 'godina';                                                              // 63
            }                                                                                    // 64
            return result;                                                                       // 65
        }                                                                                        // 66
    }                                                                                            // 67
                                                                                                 // 68
    return moment.defineLocale('hr', {                                                           // 69
        months : 'sječanj_veljača_ožujak_travanj_svibanj_lipanj_srpanj_kolovoz_rujan_listopad_studeni_prosinac'.split('_'),
        monthsShort : 'sje._vel._ožu._tra._svi._lip._srp._kol._ruj._lis._stu._pro.'.split('_'),  // 71
        weekdays : 'nedjelja_ponedjeljak_utorak_srijeda_četvrtak_petak_subota'.split('_'),       // 72
        weekdaysShort : 'ned._pon._uto._sri._čet._pet._sub.'.split('_'),                         // 73
        weekdaysMin : 'ne_po_ut_sr_če_pe_su'.split('_'),                                         // 74
        longDateFormat : {                                                                       // 75
            LT : 'H:mm',                                                                         // 76
            LTS : 'LT:ss',                                                                       // 77
            L : 'DD. MM. YYYY',                                                                  // 78
            LL : 'D. MMMM YYYY',                                                                 // 79
            LLL : 'D. MMMM YYYY LT',                                                             // 80
            LLLL : 'dddd, D. MMMM YYYY LT'                                                       // 81
        },                                                                                       // 82
        calendar : {                                                                             // 83
            sameDay  : '[danas u] LT',                                                           // 84
            nextDay  : '[sutra u] LT',                                                           // 85
                                                                                                 // 86
            nextWeek : function () {                                                             // 87
                switch (this.day()) {                                                            // 88
                case 0:                                                                          // 89
                    return '[u] [nedjelju] [u] LT';                                              // 90
                case 3:                                                                          // 91
                    return '[u] [srijedu] [u] LT';                                               // 92
                case 6:                                                                          // 93
                    return '[u] [subotu] [u] LT';                                                // 94
                case 1:                                                                          // 95
                case 2:                                                                          // 96
                case 4:                                                                          // 97
                case 5:                                                                          // 98
                    return '[u] dddd [u] LT';                                                    // 99
                }                                                                                // 100
            },                                                                                   // 101
            lastDay  : '[jučer u] LT',                                                           // 102
            lastWeek : function () {                                                             // 103
                switch (this.day()) {                                                            // 104
                case 0:                                                                          // 105
                case 3:                                                                          // 106
                    return '[prošlu] dddd [u] LT';                                               // 107
                case 6:                                                                          // 108
                    return '[prošle] [subote] [u] LT';                                           // 109
                case 1:                                                                          // 110
                case 2:                                                                          // 111
                case 4:                                                                          // 112
                case 5:                                                                          // 113
                    return '[prošli] dddd [u] LT';                                               // 114
                }                                                                                // 115
            },                                                                                   // 116
            sameElse : 'L'                                                                       // 117
        },                                                                                       // 118
        relativeTime : {                                                                         // 119
            future : 'za %s',                                                                    // 120
            past   : 'prije %s',                                                                 // 121
            s      : 'par sekundi',                                                              // 122
            m      : translate,                                                                  // 123
            mm     : translate,                                                                  // 124
            h      : translate,                                                                  // 125
            hh     : translate,                                                                  // 126
            d      : 'dan',                                                                      // 127
            dd     : translate,                                                                  // 128
            M      : 'mjesec',                                                                   // 129
            MM     : translate,                                                                  // 130
            y      : 'godinu',                                                                   // 131
            yy     : translate                                                                   // 132
        },                                                                                       // 133
        ordinalParse: /\d{1,2}\./,                                                               // 134
        ordinal : '%d.',                                                                         // 135
        week : {                                                                                 // 136
            dow : 1, // Monday is the first day of the week.                                     // 137
            doy : 7  // The week that contains Jan 1st is the first week of the year.            // 138
        }                                                                                        // 139
    });                                                                                          // 140
}));                                                                                             // 141
                                                                                                 // 142
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-hr'] = {};

})();

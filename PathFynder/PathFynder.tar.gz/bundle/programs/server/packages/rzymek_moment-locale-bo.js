(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/rzymek_moment-locale-bo/packages/rzymek_moment-locale-bo.js                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/rzymek:moment-locale-bo/server.js                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
global.moment = moment;                                                                                        // 1
                                                                                                               // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/rzymek:moment-locale-bo/locale.js                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
// moment.js locale configuration                                                                              // 1
// locale : tibetan (bo)                                                                                       // 2
// author : Thupten N. Chakrishar : https://github.com/vajradog                                                // 3
                                                                                                               // 4
(function (factory) {                                                                                          // 5
    if (typeof define === 'function' && define.amd) {                                                          // 6
        define(['moment'], factory); // AMD                                                                    // 7
    } else if (typeof exports === 'object') {                                                                  // 8
        module.exports = factory(require('../moment')); // Node                                                // 9
    } else {                                                                                                   // 10
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global               // 11
    }                                                                                                          // 12
}(function (moment) {                                                                                          // 13
    var symbolMap = {                                                                                          // 14
        '1': '༡',                                                                                              // 15
        '2': '༢',                                                                                              // 16
        '3': '༣',                                                                                              // 17
        '4': '༤',                                                                                              // 18
        '5': '༥',                                                                                              // 19
        '6': '༦',                                                                                              // 20
        '7': '༧',                                                                                              // 21
        '8': '༨',                                                                                              // 22
        '9': '༩',                                                                                              // 23
        '0': '༠'                                                                                               // 24
    },                                                                                                         // 25
    numberMap = {                                                                                              // 26
        '༡': '1',                                                                                              // 27
        '༢': '2',                                                                                              // 28
        '༣': '3',                                                                                              // 29
        '༤': '4',                                                                                              // 30
        '༥': '5',                                                                                              // 31
        '༦': '6',                                                                                              // 32
        '༧': '7',                                                                                              // 33
        '༨': '8',                                                                                              // 34
        '༩': '9',                                                                                              // 35
        '༠': '0'                                                                                               // 36
    };                                                                                                         // 37
                                                                                                               // 38
    return moment.defineLocale('bo', {                                                                         // 39
        months : 'ཟླ་བ་དང་པོ_ཟླ་བ་གཉིས་པ_ཟླ་བ་གསུམ་པ_ཟླ་བ་བཞི་པ_ཟླ་བ་ལྔ་པ_ཟླ་བ་དྲུག་པ_ཟླ་བ་བདུན་པ_ཟླ་བ་བརྒྱད་པ_ཟླ་བ་དགུ་པ_ཟླ་བ་བཅུ་པ_ཟླ་བ་བཅུ་གཅིག་པ_ཟླ་བ་བཅུ་གཉིས་པ'.split('_'),
        monthsShort : 'ཟླ་བ་དང་པོ_ཟླ་བ་གཉིས་པ_ཟླ་བ་གསུམ་པ_ཟླ་བ་བཞི་པ_ཟླ་བ་ལྔ་པ_ཟླ་བ་དྲུག་པ_ཟླ་བ་བདུན་པ_ཟླ་བ་བརྒྱད་པ_ཟླ་བ་དགུ་པ_ཟླ་བ་བཅུ་པ_ཟླ་བ་བཅུ་གཅིག་པ_ཟླ་བ་བཅུ་གཉིས་པ'.split('_'),
        weekdays : 'གཟའ་ཉི་མ་_གཟའ་ཟླ་བ་_གཟའ་མིག་དམར་_གཟའ་ལྷག་པ་_གཟའ་ཕུར་བུ_གཟའ་པ་སངས་_གཟའ་སྤེན་པ་'.split('_'), // 42
        weekdaysShort : 'ཉི་མ་_ཟླ་བ་_མིག་དམར་_ལྷག་པ་_ཕུར་བུ_པ་སངས་_སྤེན་པ་'.split('_'),                        // 43
        weekdaysMin : 'ཉི་མ་_ཟླ་བ་_མིག་དམར་_ལྷག་པ་_ཕུར་བུ_པ་སངས་_སྤེན་པ་'.split('_'),                          // 44
        longDateFormat : {                                                                                     // 45
            LT : 'A h:mm',                                                                                     // 46
            LTS : 'LT:ss',                                                                                     // 47
            L : 'DD/MM/YYYY',                                                                                  // 48
            LL : 'D MMMM YYYY',                                                                                // 49
            LLL : 'D MMMM YYYY, LT',                                                                           // 50
            LLLL : 'dddd, D MMMM YYYY, LT'                                                                     // 51
        },                                                                                                     // 52
        calendar : {                                                                                           // 53
            sameDay : '[དི་རིང] LT',                                                                           // 54
            nextDay : '[སང་ཉིན] LT',                                                                           // 55
            nextWeek : '[བདུན་ཕྲག་རྗེས་མ], LT',                                                                // 56
            lastDay : '[ཁ་སང] LT',                                                                             // 57
            lastWeek : '[བདུན་ཕྲག་མཐའ་མ] dddd, LT',                                                            // 58
            sameElse : 'L'                                                                                     // 59
        },                                                                                                     // 60
        relativeTime : {                                                                                       // 61
            future : '%s ལ་',                                                                                  // 62
            past : '%s སྔན་ལ',                                                                                 // 63
            s : 'ལམ་སང',                                                                                       // 64
            m : 'སྐར་མ་གཅིག',                                                                                  // 65
            mm : '%d སྐར་མ',                                                                                   // 66
            h : 'ཆུ་ཚོད་གཅིག',                                                                                 // 67
            hh : '%d ཆུ་ཚོད',                                                                                  // 68
            d : 'ཉིན་གཅིག',                                                                                    // 69
            dd : '%d ཉིན་',                                                                                    // 70
            M : 'ཟླ་བ་གཅིག',                                                                                   // 71
            MM : '%d ཟླ་བ',                                                                                    // 72
            y : 'ལོ་གཅིག',                                                                                     // 73
            yy : '%d ལོ'                                                                                       // 74
        },                                                                                                     // 75
        preparse: function (string) {                                                                          // 76
            return string.replace(/[༡༢༣༤༥༦༧༨༩༠]/g, function (match) {                                          // 77
                return numberMap[match];                                                                       // 78
            });                                                                                                // 79
        },                                                                                                     // 80
        postformat: function (string) {                                                                        // 81
            return string.replace(/\d/g, function (match) {                                                    // 82
                return symbolMap[match];                                                                       // 83
            });                                                                                                // 84
        },                                                                                                     // 85
        meridiemParse: /མཚན་མོ|ཞོགས་ཀས|ཉིན་གུང|དགོང་དག|མཚན་མོ/,                                                // 86
        isPM: function (input) {                                                                               // 87
            return /^(ཉིན་གུང|དགོང་དག|མཚན་མོ)$/.test(input);                                                   // 88
        },                                                                                                     // 89
        meridiem : function (hour, minute, isLower) {                                                          // 90
            if (hour < 4) {                                                                                    // 91
                return 'མཚན་མོ';                                                                               // 92
            } else if (hour < 10) {                                                                            // 93
                return 'ཞོགས་ཀས';                                                                              // 94
            } else if (hour < 17) {                                                                            // 95
                return 'ཉིན་གུང';                                                                              // 96
            } else if (hour < 20) {                                                                            // 97
                return 'དགོང་དག';                                                                              // 98
            } else {                                                                                           // 99
                return 'མཚན་མོ';                                                                               // 100
            }                                                                                                  // 101
        },                                                                                                     // 102
        week : {                                                                                               // 103
            dow : 0, // Sunday is the first day of the week.                                                   // 104
            doy : 6  // The week that contains Jan 1st is the first week of the year.                          // 105
        }                                                                                                      // 106
    });                                                                                                        // 107
}));                                                                                                           // 108
                                                                                                               // 109
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-bo'] = {};

})();

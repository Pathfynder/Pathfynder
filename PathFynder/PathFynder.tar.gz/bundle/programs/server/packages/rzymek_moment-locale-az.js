(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/rzymek_moment-locale-az/packages/rzymek_moment-locale-az.js                                            //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/rzymek:moment-locale-az/server.js                                                               //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
global.moment = moment;                                                                                     // 1
                                                                                                            // 2
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/rzymek:moment-locale-az/locale.js                                                               //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
// moment.js locale configuration                                                                           // 1
// locale : azerbaijani (az)                                                                                // 2
// author : topchiyev : https://github.com/topchiyev                                                        // 3
                                                                                                            // 4
(function (factory) {                                                                                       // 5
    if (typeof define === 'function' && define.amd) {                                                       // 6
        define(['moment'], factory); // AMD                                                                 // 7
    } else if (typeof exports === 'object') {                                                               // 8
        module.exports = factory(require('../moment')); // Node                                             // 9
    } else {                                                                                                // 10
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global            // 11
    }                                                                                                       // 12
}(function (moment) {                                                                                       // 13
    var suffixes = {                                                                                        // 14
        1: '-inci',                                                                                         // 15
        5: '-inci',                                                                                         // 16
        8: '-inci',                                                                                         // 17
        70: '-inci',                                                                                        // 18
        80: '-inci',                                                                                        // 19
                                                                                                            // 20
        2: '-nci',                                                                                          // 21
        7: '-nci',                                                                                          // 22
        20: '-nci',                                                                                         // 23
        50: '-nci',                                                                                         // 24
                                                                                                            // 25
        3: '-üncü',                                                                                         // 26
        4: '-üncü',                                                                                         // 27
        100: '-üncü',                                                                                       // 28
                                                                                                            // 29
        6: '-ncı',                                                                                          // 30
                                                                                                            // 31
        9: '-uncu',                                                                                         // 32
        10: '-uncu',                                                                                        // 33
        30: '-uncu',                                                                                        // 34
                                                                                                            // 35
        60: '-ıncı',                                                                                        // 36
        90: '-ıncı'                                                                                         // 37
    };                                                                                                      // 38
    return moment.defineLocale('az', {                                                                      // 39
        months : 'yanvar_fevral_mart_aprel_may_iyun_iyul_avqust_sentyabr_oktyabr_noyabr_dekabr'.split('_'), // 40
        monthsShort : 'yan_fev_mar_apr_may_iyn_iyl_avq_sen_okt_noy_dek'.split('_'),                         // 41
        weekdays : 'Bazar_Bazar ertəsi_Çərşənbə axşamı_Çərşənbə_Cümə axşamı_Cümə_Şənbə'.split('_'),         // 42
        weekdaysShort : 'Baz_BzE_ÇAx_Çər_CAx_Cüm_Şən'.split('_'),                                           // 43
        weekdaysMin : 'Bz_BE_ÇA_Çə_CA_Cü_Şə'.split('_'),                                                    // 44
        longDateFormat : {                                                                                  // 45
            LT : 'HH:mm',                                                                                   // 46
            LTS : 'LT:ss',                                                                                  // 47
            L : 'DD.MM.YYYY',                                                                               // 48
            LL : 'D MMMM YYYY',                                                                             // 49
            LLL : 'D MMMM YYYY LT',                                                                         // 50
            LLLL : 'dddd, D MMMM YYYY LT'                                                                   // 51
        },                                                                                                  // 52
        calendar : {                                                                                        // 53
            sameDay : '[bugün saat] LT',                                                                    // 54
            nextDay : '[sabah saat] LT',                                                                    // 55
            nextWeek : '[gələn həftə] dddd [saat] LT',                                                      // 56
            lastDay : '[dünən] LT',                                                                         // 57
            lastWeek : '[keçən həftə] dddd [saat] LT',                                                      // 58
            sameElse : 'L'                                                                                  // 59
        },                                                                                                  // 60
        relativeTime : {                                                                                    // 61
            future : '%s sonra',                                                                            // 62
            past : '%s əvvəl',                                                                              // 63
            s : 'birneçə saniyyə',                                                                          // 64
            m : 'bir dəqiqə',                                                                               // 65
            mm : '%d dəqiqə',                                                                               // 66
            h : 'bir saat',                                                                                 // 67
            hh : '%d saat',                                                                                 // 68
            d : 'bir gün',                                                                                  // 69
            dd : '%d gün',                                                                                  // 70
            M : 'bir ay',                                                                                   // 71
            MM : '%d ay',                                                                                   // 72
            y : 'bir il',                                                                                   // 73
            yy : '%d il'                                                                                    // 74
        },                                                                                                  // 75
        meridiemParse: /gecə|səhər|gündüz|axşam/,                                                           // 76
        isPM : function (input) {                                                                           // 77
            return /^(gündüz|axşam)$/.test(input);                                                          // 78
        },                                                                                                  // 79
        meridiem : function (hour, minute, isLower) {                                                       // 80
            if (hour < 4) {                                                                                 // 81
                return 'gecə';                                                                              // 82
            } else if (hour < 12) {                                                                         // 83
                return 'səhər';                                                                             // 84
            } else if (hour < 17) {                                                                         // 85
                return 'gündüz';                                                                            // 86
            } else {                                                                                        // 87
                return 'axşam';                                                                             // 88
            }                                                                                               // 89
        },                                                                                                  // 90
        ordinalParse: /\d{1,2}-(ıncı|inci|nci|üncü|ncı|uncu)/,                                              // 91
        ordinal : function (number) {                                                                       // 92
            if (number === 0) {  // special case for zero                                                   // 93
                return number + '-ıncı';                                                                    // 94
            }                                                                                               // 95
            var a = number % 10,                                                                            // 96
                b = number % 100 - a,                                                                       // 97
                c = number >= 100 ? 100 : null;                                                             // 98
                                                                                                            // 99
            return number + (suffixes[a] || suffixes[b] || suffixes[c]);                                    // 100
        },                                                                                                  // 101
        week : {                                                                                            // 102
            dow : 1, // Monday is the first day of the week.                                                // 103
            doy : 7  // The week that contains Jan 1st is the first week of the year.                       // 104
        }                                                                                                   // 105
    });                                                                                                     // 106
}));                                                                                                        // 107
                                                                                                            // 108
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-az'] = {};

})();

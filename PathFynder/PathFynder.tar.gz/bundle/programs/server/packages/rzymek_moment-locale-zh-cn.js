(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/rzymek_moment-locale-zh-cn/packages/rzymek_moment-locale-zh-cn.js                           //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/rzymek:moment-locale-zh-cn/server.js                                                 //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
global.moment = moment;                                                                          // 1
                                                                                                 // 2
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/rzymek:moment-locale-zh-cn/locale.js                                                 //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
// moment.js locale configuration                                                                // 1
// locale : chinese (zh-cn)                                                                      // 2
// author : suupic : https://github.com/suupic                                                   // 3
// author : Zeno Zeng : https://github.com/zenozeng                                              // 4
                                                                                                 // 5
(function (factory) {                                                                            // 6
    if (typeof define === 'function' && define.amd) {                                            // 7
        define(['moment'], factory); // AMD                                                      // 8
    } else if (typeof exports === 'object') {                                                    // 9
        module.exports = factory(require('../moment')); // Node                                  // 10
    } else {                                                                                     // 11
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global // 12
    }                                                                                            // 13
}(function (moment) {                                                                            // 14
    return moment.defineLocale('zh-cn', {                                                        // 15
        months : '一月_二月_三月_四月_五月_六月_七月_八月_九月_十月_十一月_十二月'.split('_'),                             // 16
        monthsShort : '1月_2月_3月_4月_5月_6月_7月_8月_9月_10月_11月_12月'.split('_'),                       // 17
        weekdays : '星期日_星期一_星期二_星期三_星期四_星期五_星期六'.split('_'),                                     // 18
        weekdaysShort : '周日_周一_周二_周三_周四_周五_周六'.split('_'),                                       // 19
        weekdaysMin : '日_一_二_三_四_五_六'.split('_'),                                                // 20
        longDateFormat : {                                                                       // 21
            LT : 'Ah点mm',                                                                        // 22
            LTS : 'Ah点m分s秒',                                                                     // 23
            L : 'YYYY-MM-DD',                                                                    // 24
            LL : 'YYYY年MMMD日',                                                                   // 25
            LLL : 'YYYY年MMMD日LT',                                                                // 26
            LLLL : 'YYYY年MMMD日ddddLT',                                                           // 27
            l : 'YYYY-MM-DD',                                                                    // 28
            ll : 'YYYY年MMMD日',                                                                   // 29
            lll : 'YYYY年MMMD日LT',                                                                // 30
            llll : 'YYYY年MMMD日ddddLT'                                                            // 31
        },                                                                                       // 32
        meridiemParse: /凌晨|早上|上午|中午|下午|晚上/,                                                      // 33
        meridiemHour: function (hour, meridiem) {                                                // 34
            if (hour === 12) {                                                                   // 35
                hour = 0;                                                                        // 36
            }                                                                                    // 37
            if (meridiem === '凌晨' || meridiem === '早上' ||                                        // 38
                    meridiem === '上午') {                                                         // 39
                return hour;                                                                     // 40
            } else if (meridiem === '下午' || meridiem === '晚上') {                                 // 41
                return hour + 12;                                                                // 42
            } else {                                                                             // 43
                // '中午'                                                                          // 44
                return hour >= 11 ? hour : hour + 12;                                            // 45
            }                                                                                    // 46
        },                                                                                       // 47
        meridiem : function (hour, minute, isLower) {                                            // 48
            var hm = hour * 100 + minute;                                                        // 49
            if (hm < 600) {                                                                      // 50
                return '凌晨';                                                                     // 51
            } else if (hm < 900) {                                                               // 52
                return '早上';                                                                     // 53
            } else if (hm < 1130) {                                                              // 54
                return '上午';                                                                     // 55
            } else if (hm < 1230) {                                                              // 56
                return '中午';                                                                     // 57
            } else if (hm < 1800) {                                                              // 58
                return '下午';                                                                     // 59
            } else {                                                                             // 60
                return '晚上';                                                                     // 61
            }                                                                                    // 62
        },                                                                                       // 63
        calendar : {                                                                             // 64
            sameDay : function () {                                                              // 65
                return this.minutes() === 0 ? '[今天]Ah[点整]' : '[今天]LT';                           // 66
            },                                                                                   // 67
            nextDay : function () {                                                              // 68
                return this.minutes() === 0 ? '[明天]Ah[点整]' : '[明天]LT';                           // 69
            },                                                                                   // 70
            lastDay : function () {                                                              // 71
                return this.minutes() === 0 ? '[昨天]Ah[点整]' : '[昨天]LT';                           // 72
            },                                                                                   // 73
            nextWeek : function () {                                                             // 74
                var startOfWeek, prefix;                                                         // 75
                startOfWeek = moment().startOf('week');                                          // 76
                prefix = this.unix() - startOfWeek.unix() >= 7 * 24 * 3600 ? '[下]' : '[本]';      // 77
                return this.minutes() === 0 ? prefix + 'dddAh点整' : prefix + 'dddAh点mm';          // 78
            },                                                                                   // 79
            lastWeek : function () {                                                             // 80
                var startOfWeek, prefix;                                                         // 81
                startOfWeek = moment().startOf('week');                                          // 82
                prefix = this.unix() < startOfWeek.unix()  ? '[上]' : '[本]';                      // 83
                return this.minutes() === 0 ? prefix + 'dddAh点整' : prefix + 'dddAh点mm';          // 84
            },                                                                                   // 85
            sameElse : 'LL'                                                                      // 86
        },                                                                                       // 87
        ordinalParse: /\d{1,2}(日|月|周)/,                                                          // 88
        ordinal : function (number, period) {                                                    // 89
            switch (period) {                                                                    // 90
            case 'd':                                                                            // 91
            case 'D':                                                                            // 92
            case 'DDD':                                                                          // 93
                return number + '日';                                                             // 94
            case 'M':                                                                            // 95
                return number + '月';                                                             // 96
            case 'w':                                                                            // 97
            case 'W':                                                                            // 98
                return number + '周';                                                             // 99
            default:                                                                             // 100
                return number;                                                                   // 101
            }                                                                                    // 102
        },                                                                                       // 103
        relativeTime : {                                                                         // 104
            future : '%s内',                                                                      // 105
            past : '%s前',                                                                        // 106
            s : '几秒',                                                                            // 107
            m : '1分钟',                                                                           // 108
            mm : '%d分钟',                                                                         // 109
            h : '1小时',                                                                           // 110
            hh : '%d小时',                                                                         // 111
            d : '1天',                                                                            // 112
            dd : '%d天',                                                                          // 113
            M : '1个月',                                                                           // 114
            MM : '%d个月',                                                                         // 115
            y : '1年',                                                                            // 116
            yy : '%d年'                                                                           // 117
        },                                                                                       // 118
        week : {                                                                                 // 119
            // GB/T 7408-1994《数据元和交换格式·信息交换·日期和时间表示法》与ISO 8601:1988等效                            // 120
            dow : 1, // Monday is the first day of the week.                                     // 121
            doy : 4  // The week that contains Jan 4th is the first week of the year.            // 122
        }                                                                                        // 123
    });                                                                                          // 124
}));                                                                                             // 125
                                                                                                 // 126
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-zh-cn'] = {};

})();

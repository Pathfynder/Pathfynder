(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/rzymek_moment-locale-uk/packages/rzymek_moment-locale-uk.js                                 //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/rzymek:moment-locale-uk/server.js                                                    //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
global.moment = moment;                                                                          // 1
                                                                                                 // 2
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/rzymek:moment-locale-uk/locale.js                                                    //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
// moment.js locale configuration                                                                // 1
// locale : ukrainian (uk)                                                                       // 2
// author : zemlanin : https://github.com/zemlanin                                               // 3
// Author : Menelion Elensúle : https://github.com/Oire                                          // 4
                                                                                                 // 5
(function (factory) {                                                                            // 6
    if (typeof define === 'function' && define.amd) {                                            // 7
        define(['moment'], factory); // AMD                                                      // 8
    } else if (typeof exports === 'object') {                                                    // 9
        module.exports = factory(require('../moment')); // Node                                  // 10
    } else {                                                                                     // 11
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global // 12
    }                                                                                            // 13
}(function (moment) {                                                                            // 14
    function plural(word, num) {                                                                 // 15
        var forms = word.split('_');                                                             // 16
        return num % 10 === 1 && num % 100 !== 11 ? forms[0] : (num % 10 >= 2 && num % 10 <= 4 && (num % 100 < 10 || num % 100 >= 20) ? forms[1] : forms[2]);
    }                                                                                            // 18
                                                                                                 // 19
    function relativeTimeWithPlural(number, withoutSuffix, key) {                                // 20
        var format = {                                                                           // 21
            'mm': 'хвилина_хвилини_хвилин',                                                      // 22
            'hh': 'година_години_годин',                                                         // 23
            'dd': 'день_дні_днів',                                                               // 24
            'MM': 'місяць_місяці_місяців',                                                       // 25
            'yy': 'рік_роки_років'                                                               // 26
        };                                                                                       // 27
        if (key === 'm') {                                                                       // 28
            return withoutSuffix ? 'хвилина' : 'хвилину';                                        // 29
        }                                                                                        // 30
        else if (key === 'h') {                                                                  // 31
            return withoutSuffix ? 'година' : 'годину';                                          // 32
        }                                                                                        // 33
        else {                                                                                   // 34
            return number + ' ' + plural(format[key], +number);                                  // 35
        }                                                                                        // 36
    }                                                                                            // 37
                                                                                                 // 38
    function monthsCaseReplace(m, format) {                                                      // 39
        var months = {                                                                           // 40
            'nominative': 'січень_лютий_березень_квітень_травень_червень_липень_серпень_вересень_жовтень_листопад_грудень'.split('_'),
            'accusative': 'січня_лютого_березня_квітня_травня_червня_липня_серпня_вересня_жовтня_листопада_грудня'.split('_')
        },                                                                                       // 43
                                                                                                 // 44
        nounCase = (/D[oD]? *MMMM?/).test(format) ?                                              // 45
            'accusative' :                                                                       // 46
            'nominative';                                                                        // 47
                                                                                                 // 48
        return months[nounCase][m.month()];                                                      // 49
    }                                                                                            // 50
                                                                                                 // 51
    function weekdaysCaseReplace(m, format) {                                                    // 52
        var weekdays = {                                                                         // 53
            'nominative': 'неділя_понеділок_вівторок_середа_четвер_п’ятниця_субота'.split('_'),  // 54
            'accusative': 'неділю_понеділок_вівторок_середу_четвер_п’ятницю_суботу'.split('_'),  // 55
            'genitive': 'неділі_понеділка_вівторка_середи_четверга_п’ятниці_суботи'.split('_')   // 56
        },                                                                                       // 57
                                                                                                 // 58
        nounCase = (/(\[[ВвУу]\]) ?dddd/).test(format) ?                                         // 59
            'accusative' :                                                                       // 60
            ((/\[?(?:минулої|наступної)? ?\] ?dddd/).test(format) ?                              // 61
                'genitive' :                                                                     // 62
                'nominative');                                                                   // 63
                                                                                                 // 64
        return weekdays[nounCase][m.day()];                                                      // 65
    }                                                                                            // 66
                                                                                                 // 67
    function processHoursFunction(str) {                                                         // 68
        return function () {                                                                     // 69
            return str + 'о' + (this.hours() === 11 ? 'б' : '') + '] LT';                        // 70
        };                                                                                       // 71
    }                                                                                            // 72
                                                                                                 // 73
    return moment.defineLocale('uk', {                                                           // 74
        months : monthsCaseReplace,                                                              // 75
        monthsShort : 'січ_лют_бер_квіт_трав_черв_лип_серп_вер_жовт_лист_груд'.split('_'),       // 76
        weekdays : weekdaysCaseReplace,                                                          // 77
        weekdaysShort : 'нд_пн_вт_ср_чт_пт_сб'.split('_'),                                       // 78
        weekdaysMin : 'нд_пн_вт_ср_чт_пт_сб'.split('_'),                                         // 79
        longDateFormat : {                                                                       // 80
            LT : 'HH:mm',                                                                        // 81
            LTS : 'LT:ss',                                                                       // 82
            L : 'DD.MM.YYYY',                                                                    // 83
            LL : 'D MMMM YYYY р.',                                                               // 84
            LLL : 'D MMMM YYYY р., LT',                                                          // 85
            LLLL : 'dddd, D MMMM YYYY р., LT'                                                    // 86
        },                                                                                       // 87
        calendar : {                                                                             // 88
            sameDay: processHoursFunction('[Сьогодні '),                                         // 89
            nextDay: processHoursFunction('[Завтра '),                                           // 90
            lastDay: processHoursFunction('[Вчора '),                                            // 91
            nextWeek: processHoursFunction('[У] dddd ['),                                        // 92
            lastWeek: function () {                                                              // 93
                switch (this.day()) {                                                            // 94
                case 0:                                                                          // 95
                case 3:                                                                          // 96
                case 5:                                                                          // 97
                case 6:                                                                          // 98
                    return processHoursFunction('[Минулої] dddd [').call(this);                  // 99
                case 1:                                                                          // 100
                case 2:                                                                          // 101
                case 4:                                                                          // 102
                    return processHoursFunction('[Минулого] dddd [').call(this);                 // 103
                }                                                                                // 104
            },                                                                                   // 105
            sameElse: 'L'                                                                        // 106
        },                                                                                       // 107
        relativeTime : {                                                                         // 108
            future : 'за %s',                                                                    // 109
            past : '%s тому',                                                                    // 110
            s : 'декілька секунд',                                                               // 111
            m : relativeTimeWithPlural,                                                          // 112
            mm : relativeTimeWithPlural,                                                         // 113
            h : 'годину',                                                                        // 114
            hh : relativeTimeWithPlural,                                                         // 115
            d : 'день',                                                                          // 116
            dd : relativeTimeWithPlural,                                                         // 117
            M : 'місяць',                                                                        // 118
            MM : relativeTimeWithPlural,                                                         // 119
            y : 'рік',                                                                           // 120
            yy : relativeTimeWithPlural                                                          // 121
        },                                                                                       // 122
                                                                                                 // 123
        // M. E.: those two are virtually unused but a user might want to implement them for his/her website for some reason
                                                                                                 // 125
        meridiemParse: /ночі|ранку|дня|вечора/,                                                  // 126
        isPM: function (input) {                                                                 // 127
            return /^(дня|вечора)$/.test(input);                                                 // 128
        },                                                                                       // 129
        meridiem : function (hour, minute, isLower) {                                            // 130
            if (hour < 4) {                                                                      // 131
                return 'ночі';                                                                   // 132
            } else if (hour < 12) {                                                              // 133
                return 'ранку';                                                                  // 134
            } else if (hour < 17) {                                                              // 135
                return 'дня';                                                                    // 136
            } else {                                                                             // 137
                return 'вечора';                                                                 // 138
            }                                                                                    // 139
        },                                                                                       // 140
                                                                                                 // 141
        ordinalParse: /\d{1,2}-(й|го)/,                                                          // 142
        ordinal: function (number, period) {                                                     // 143
            switch (period) {                                                                    // 144
            case 'M':                                                                            // 145
            case 'd':                                                                            // 146
            case 'DDD':                                                                          // 147
            case 'w':                                                                            // 148
            case 'W':                                                                            // 149
                return number + '-й';                                                            // 150
            case 'D':                                                                            // 151
                return number + '-го';                                                           // 152
            default:                                                                             // 153
                return number;                                                                   // 154
            }                                                                                    // 155
        },                                                                                       // 156
                                                                                                 // 157
        week : {                                                                                 // 158
            dow : 1, // Monday is the first day of the week.                                     // 159
            doy : 7  // The week that contains Jan 1st is the first week of the year.            // 160
        }                                                                                        // 161
    });                                                                                          // 162
}));                                                                                             // 163
                                                                                                 // 164
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-uk'] = {};

})();

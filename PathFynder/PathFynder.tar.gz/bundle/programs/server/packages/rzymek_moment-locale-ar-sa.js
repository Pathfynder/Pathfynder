(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/rzymek_moment-locale-ar-sa/packages/rzymek_moment-locale-ar-sa.js                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/rzymek:moment-locale-ar-sa/server.js                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
global.moment = moment;                                                                                        // 1
                                                                                                               // 2
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/rzymek:moment-locale-ar-sa/locale.js                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
// moment.js locale configuration                                                                              // 1
// locale : Arabic Saudi Arabia (ar-sa)                                                                        // 2
// author : Suhail Alkowaileet : https://github.com/xsoh                                                       // 3
                                                                                                               // 4
(function (factory) {                                                                                          // 5
    if (typeof define === 'function' && define.amd) {                                                          // 6
        define(['moment'], factory); // AMD                                                                    // 7
    } else if (typeof exports === 'object') {                                                                  // 8
        module.exports = factory(require('../moment')); // Node                                                // 9
    } else {                                                                                                   // 10
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global               // 11
    }                                                                                                          // 12
}(function (moment) {                                                                                          // 13
    var symbolMap = {                                                                                          // 14
        '1': '١',                                                                                              // 15
        '2': '٢',                                                                                              // 16
        '3': '٣',                                                                                              // 17
        '4': '٤',                                                                                              // 18
        '5': '٥',                                                                                              // 19
        '6': '٦',                                                                                              // 20
        '7': '٧',                                                                                              // 21
        '8': '٨',                                                                                              // 22
        '9': '٩',                                                                                              // 23
        '0': '٠'                                                                                               // 24
    }, numberMap = {                                                                                           // 25
        '١': '1',                                                                                              // 26
        '٢': '2',                                                                                              // 27
        '٣': '3',                                                                                              // 28
        '٤': '4',                                                                                              // 29
        '٥': '5',                                                                                              // 30
        '٦': '6',                                                                                              // 31
        '٧': '7',                                                                                              // 32
        '٨': '8',                                                                                              // 33
        '٩': '9',                                                                                              // 34
        '٠': '0'                                                                                               // 35
    };                                                                                                         // 36
                                                                                                               // 37
    return moment.defineLocale('ar-sa', {                                                                      // 38
        months : 'يناير_فبراير_مارس_أبريل_مايو_يونيو_يوليو_أغسطس_سبتمبر_أكتوبر_نوفمبر_ديسمبر'.split('_'),      // 39
        monthsShort : 'يناير_فبراير_مارس_أبريل_مايو_يونيو_يوليو_أغسطس_سبتمبر_أكتوبر_نوفمبر_ديسمبر'.split('_'), // 40
        weekdays : 'الأحد_الإثنين_الثلاثاء_الأربعاء_الخميس_الجمعة_السبت'.split('_'),                           // 41
        weekdaysShort : 'أحد_إثنين_ثلاثاء_أربعاء_خميس_جمعة_سبت'.split('_'),                                    // 42
        weekdaysMin : 'ح_ن_ث_ر_خ_ج_س'.split('_'),                                                              // 43
        longDateFormat : {                                                                                     // 44
            LT : 'HH:mm',                                                                                      // 45
            LTS : 'HH:mm:ss',                                                                                  // 46
            L : 'DD/MM/YYYY',                                                                                  // 47
            LL : 'D MMMM YYYY',                                                                                // 48
            LLL : 'D MMMM YYYY LT',                                                                            // 49
            LLLL : 'dddd D MMMM YYYY LT'                                                                       // 50
        },                                                                                                     // 51
        meridiemParse: /ص|م/,                                                                                  // 52
        isPM : function (input) {                                                                              // 53
            return 'م' === input;                                                                              // 54
        },                                                                                                     // 55
        meridiem : function (hour, minute, isLower) {                                                          // 56
            if (hour < 12) {                                                                                   // 57
                return 'ص';                                                                                    // 58
            } else {                                                                                           // 59
                return 'م';                                                                                    // 60
            }                                                                                                  // 61
        },                                                                                                     // 62
        calendar : {                                                                                           // 63
            sameDay: '[اليوم على الساعة] LT',                                                                  // 64
            nextDay: '[غدا على الساعة] LT',                                                                    // 65
            nextWeek: 'dddd [على الساعة] LT',                                                                  // 66
            lastDay: '[أمس على الساعة] LT',                                                                    // 67
            lastWeek: 'dddd [على الساعة] LT',                                                                  // 68
            sameElse: 'L'                                                                                      // 69
        },                                                                                                     // 70
        relativeTime : {                                                                                       // 71
            future : 'في %s',                                                                                  // 72
            past : 'منذ %s',                                                                                   // 73
            s : 'ثوان',                                                                                        // 74
            m : 'دقيقة',                                                                                       // 75
            mm : '%d دقائق',                                                                                   // 76
            h : 'ساعة',                                                                                        // 77
            hh : '%d ساعات',                                                                                   // 78
            d : 'يوم',                                                                                         // 79
            dd : '%d أيام',                                                                                    // 80
            M : 'شهر',                                                                                         // 81
            MM : '%d أشهر',                                                                                    // 82
            y : 'سنة',                                                                                         // 83
            yy : '%d سنوات'                                                                                    // 84
        },                                                                                                     // 85
        preparse: function (string) {                                                                          // 86
            return string.replace(/[١٢٣٤٥٦٧٨٩٠]/g, function (match) {                                          // 87
                return numberMap[match];                                                                       // 88
            }).replace(/،/g, ',');                                                                             // 89
        },                                                                                                     // 90
        postformat: function (string) {                                                                        // 91
            return string.replace(/\d/g, function (match) {                                                    // 92
                return symbolMap[match];                                                                       // 93
            }).replace(/,/g, '،');                                                                             // 94
        },                                                                                                     // 95
        week : {                                                                                               // 96
            dow : 6, // Saturday is the first day of the week.                                                 // 97
            doy : 12  // The week that contains Jan 1st is the first week of the year.                         // 98
        }                                                                                                      // 99
    });                                                                                                        // 100
}));                                                                                                           // 101
                                                                                                               // 102
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-ar-sa'] = {};

})();

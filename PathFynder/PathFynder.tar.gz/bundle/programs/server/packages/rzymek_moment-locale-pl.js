(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/rzymek_moment-locale-pl/packages/rzymek_moment-locale-pl.js                                 //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/rzymek:moment-locale-pl/server.js                                                    //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
global.moment = moment;                                                                          // 1
                                                                                                 // 2
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/rzymek:moment-locale-pl/locale.js                                                    //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
// moment.js locale configuration                                                                // 1
// locale : polish (pl)                                                                          // 2
// author : Rafal Hirsz : https://github.com/evoL                                                // 3
                                                                                                 // 4
(function (factory) {                                                                            // 5
    if (typeof define === 'function' && define.amd) {                                            // 6
        define(['moment'], factory); // AMD                                                      // 7
    } else if (typeof exports === 'object') {                                                    // 8
        module.exports = factory(require('../moment')); // Node                                  // 9
    } else {                                                                                     // 10
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global // 11
    }                                                                                            // 12
}(function (moment) {                                                                            // 13
    var monthsNominative = 'styczeń_luty_marzec_kwiecień_maj_czerwiec_lipiec_sierpień_wrzesień_październik_listopad_grudzień'.split('_'),
        monthsSubjective = 'stycznia_lutego_marca_kwietnia_maja_czerwca_lipca_sierpnia_września_października_listopada_grudnia'.split('_');
                                                                                                 // 16
    function plural(n) {                                                                         // 17
        return (n % 10 < 5) && (n % 10 > 1) && ((~~(n / 10) % 10) !== 1);                        // 18
    }                                                                                            // 19
                                                                                                 // 20
    function translate(number, withoutSuffix, key) {                                             // 21
        var result = number + ' ';                                                               // 22
        switch (key) {                                                                           // 23
        case 'm':                                                                                // 24
            return withoutSuffix ? 'minuta' : 'minutę';                                          // 25
        case 'mm':                                                                               // 26
            return result + (plural(number) ? 'minuty' : 'minut');                               // 27
        case 'h':                                                                                // 28
            return withoutSuffix  ? 'godzina'  : 'godzinę';                                      // 29
        case 'hh':                                                                               // 30
            return result + (plural(number) ? 'godziny' : 'godzin');                             // 31
        case 'MM':                                                                               // 32
            return result + (plural(number) ? 'miesiące' : 'miesięcy');                          // 33
        case 'yy':                                                                               // 34
            return result + (plural(number) ? 'lata' : 'lat');                                   // 35
        }                                                                                        // 36
    }                                                                                            // 37
                                                                                                 // 38
    return moment.defineLocale('pl', {                                                           // 39
        months : function (momentToFormat, format) {                                             // 40
            if (/D MMMM/.test(format)) {                                                         // 41
                return monthsSubjective[momentToFormat.month()];                                 // 42
            } else {                                                                             // 43
                return monthsNominative[momentToFormat.month()];                                 // 44
            }                                                                                    // 45
        },                                                                                       // 46
        monthsShort : 'sty_lut_mar_kwi_maj_cze_lip_sie_wrz_paź_lis_gru'.split('_'),              // 47
        weekdays : 'niedziela_poniedziałek_wtorek_środa_czwartek_piątek_sobota'.split('_'),      // 48
        weekdaysShort : 'nie_pon_wt_śr_czw_pt_sb'.split('_'),                                    // 49
        weekdaysMin : 'N_Pn_Wt_Śr_Cz_Pt_So'.split('_'),                                          // 50
        longDateFormat : {                                                                       // 51
            LT : 'HH:mm',                                                                        // 52
            LTS : 'LT:ss',                                                                       // 53
            L : 'DD.MM.YYYY',                                                                    // 54
            LL : 'D MMMM YYYY',                                                                  // 55
            LLL : 'D MMMM YYYY LT',                                                              // 56
            LLLL : 'dddd, D MMMM YYYY LT'                                                        // 57
        },                                                                                       // 58
        calendar : {                                                                             // 59
            sameDay: '[Dziś o] LT',                                                              // 60
            nextDay: '[Jutro o] LT',                                                             // 61
            nextWeek: '[W] dddd [o] LT',                                                         // 62
            lastDay: '[Wczoraj o] LT',                                                           // 63
            lastWeek: function () {                                                              // 64
                switch (this.day()) {                                                            // 65
                case 0:                                                                          // 66
                    return '[W zeszłą niedzielę o] LT';                                          // 67
                case 3:                                                                          // 68
                    return '[W zeszłą środę o] LT';                                              // 69
                case 6:                                                                          // 70
                    return '[W zeszłą sobotę o] LT';                                             // 71
                default:                                                                         // 72
                    return '[W zeszły] dddd [o] LT';                                             // 73
                }                                                                                // 74
            },                                                                                   // 75
            sameElse: 'L'                                                                        // 76
        },                                                                                       // 77
        relativeTime : {                                                                         // 78
            future : 'za %s',                                                                    // 79
            past : '%s temu',                                                                    // 80
            s : 'kilka sekund',                                                                  // 81
            m : translate,                                                                       // 82
            mm : translate,                                                                      // 83
            h : translate,                                                                       // 84
            hh : translate,                                                                      // 85
            d : '1 dzień',                                                                       // 86
            dd : '%d dni',                                                                       // 87
            M : 'miesiąc',                                                                       // 88
            MM : translate,                                                                      // 89
            y : 'rok',                                                                           // 90
            yy : translate                                                                       // 91
        },                                                                                       // 92
        ordinalParse: /\d{1,2}\./,                                                               // 93
        ordinal : '%d.',                                                                         // 94
        week : {                                                                                 // 95
            dow : 1, // Monday is the first day of the week.                                     // 96
            doy : 4  // The week that contains Jan 4th is the first week of the year.            // 97
        }                                                                                        // 98
    });                                                                                          // 99
}));                                                                                             // 100
                                                                                                 // 101
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-pl'] = {};

})();

(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rzymek_moment-locale-br/packages/rzymek_moment-locale-br.js                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rzymek:moment-locale-br/server.js                                                                 //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
global.moment = moment;                                                                                       // 1
                                                                                                              // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rzymek:moment-locale-br/locale.js                                                                 //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
// moment.js locale configuration                                                                             // 1
// locale : breton (br)                                                                                       // 2
// author : Jean-Baptiste Le Duigou : https://github.com/jbleduigou                                           // 3
                                                                                                              // 4
(function (factory) {                                                                                         // 5
    if (typeof define === 'function' && define.amd) {                                                         // 6
        define(['moment'], factory); // AMD                                                                   // 7
    } else if (typeof exports === 'object') {                                                                 // 8
        module.exports = factory(require('../moment')); // Node                                               // 9
    } else {                                                                                                  // 10
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global              // 11
    }                                                                                                         // 12
}(function (moment) {                                                                                         // 13
    function relativeTimeWithMutation(number, withoutSuffix, key) {                                           // 14
        var format = {                                                                                        // 15
            'mm': 'munutenn',                                                                                 // 16
            'MM': 'miz',                                                                                      // 17
            'dd': 'devezh'                                                                                    // 18
        };                                                                                                    // 19
        return number + ' ' + mutation(format[key], number);                                                  // 20
    }                                                                                                         // 21
                                                                                                              // 22
    function specialMutationForYears(number) {                                                                // 23
        switch (lastNumber(number)) {                                                                         // 24
        case 1:                                                                                               // 25
        case 3:                                                                                               // 26
        case 4:                                                                                               // 27
        case 5:                                                                                               // 28
        case 9:                                                                                               // 29
            return number + ' bloaz';                                                                         // 30
        default:                                                                                              // 31
            return number + ' vloaz';                                                                         // 32
        }                                                                                                     // 33
    }                                                                                                         // 34
                                                                                                              // 35
    function lastNumber(number) {                                                                             // 36
        if (number > 9) {                                                                                     // 37
            return lastNumber(number % 10);                                                                   // 38
        }                                                                                                     // 39
        return number;                                                                                        // 40
    }                                                                                                         // 41
                                                                                                              // 42
    function mutation(text, number) {                                                                         // 43
        if (number === 2) {                                                                                   // 44
            return softMutation(text);                                                                        // 45
        }                                                                                                     // 46
        return text;                                                                                          // 47
    }                                                                                                         // 48
                                                                                                              // 49
    function softMutation(text) {                                                                             // 50
        var mutationTable = {                                                                                 // 51
            'm': 'v',                                                                                         // 52
            'b': 'v',                                                                                         // 53
            'd': 'z'                                                                                          // 54
        };                                                                                                    // 55
        if (mutationTable[text.charAt(0)] === undefined) {                                                    // 56
            return text;                                                                                      // 57
        }                                                                                                     // 58
        return mutationTable[text.charAt(0)] + text.substring(1);                                             // 59
    }                                                                                                         // 60
                                                                                                              // 61
    return moment.defineLocale('br', {                                                                        // 62
        months : 'Genver_C\'hwevrer_Meurzh_Ebrel_Mae_Mezheven_Gouere_Eost_Gwengolo_Here_Du_Kerzu'.split('_'), // 63
        monthsShort : 'Gen_C\'hwe_Meu_Ebr_Mae_Eve_Gou_Eos_Gwe_Her_Du_Ker'.split('_'),                         // 64
        weekdays : 'Sul_Lun_Meurzh_Merc\'her_Yaou_Gwener_Sadorn'.split('_'),                                  // 65
        weekdaysShort : 'Sul_Lun_Meu_Mer_Yao_Gwe_Sad'.split('_'),                                             // 66
        weekdaysMin : 'Su_Lu_Me_Mer_Ya_Gw_Sa'.split('_'),                                                     // 67
        longDateFormat : {                                                                                    // 68
            LT : 'h[e]mm A',                                                                                  // 69
            LTS : 'h[e]mm:ss A',                                                                              // 70
            L : 'DD/MM/YYYY',                                                                                 // 71
            LL : 'D [a viz] MMMM YYYY',                                                                       // 72
            LLL : 'D [a viz] MMMM YYYY LT',                                                                   // 73
            LLLL : 'dddd, D [a viz] MMMM YYYY LT'                                                             // 74
        },                                                                                                    // 75
        calendar : {                                                                                          // 76
            sameDay : '[Hiziv da] LT',                                                                        // 77
            nextDay : '[Warc\'hoazh da] LT',                                                                  // 78
            nextWeek : 'dddd [da] LT',                                                                        // 79
            lastDay : '[Dec\'h da] LT',                                                                       // 80
            lastWeek : 'dddd [paset da] LT',                                                                  // 81
            sameElse : 'L'                                                                                    // 82
        },                                                                                                    // 83
        relativeTime : {                                                                                      // 84
            future : 'a-benn %s',                                                                             // 85
            past : '%s \'zo',                                                                                 // 86
            s : 'un nebeud segondennoù',                                                                      // 87
            m : 'ur vunutenn',                                                                                // 88
            mm : relativeTimeWithMutation,                                                                    // 89
            h : 'un eur',                                                                                     // 90
            hh : '%d eur',                                                                                    // 91
            d : 'un devezh',                                                                                  // 92
            dd : relativeTimeWithMutation,                                                                    // 93
            M : 'ur miz',                                                                                     // 94
            MM : relativeTimeWithMutation,                                                                    // 95
            y : 'ur bloaz',                                                                                   // 96
            yy : specialMutationForYears                                                                      // 97
        },                                                                                                    // 98
        ordinalParse: /\d{1,2}(añ|vet)/,                                                                      // 99
        ordinal : function (number) {                                                                         // 100
            var output = (number === 1) ? 'añ' : 'vet';                                                       // 101
            return number + output;                                                                           // 102
        },                                                                                                    // 103
        week : {                                                                                              // 104
            dow : 1, // Monday is the first day of the week.                                                  // 105
            doy : 4  // The week that contains Jan 4th is the first week of the year.                         // 106
        }                                                                                                     // 107
    });                                                                                                       // 108
}));                                                                                                          // 109
                                                                                                              // 110
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-br'] = {};

})();

(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rzymek_moment-locale-ka/packages/rzymek_moment-locale-ka.js                                      //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/rzymek:moment-locale-ka/server.js                                                         //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
global.moment = moment;                                                                               // 1
                                                                                                      // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/rzymek:moment-locale-ka/locale.js                                                         //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
// moment.js locale configuration                                                                     // 1
// locale : Georgian (ka)                                                                             // 2
// author : Irakli Janiashvili : https://github.com/irakli-janiashvili                                // 3
                                                                                                      // 4
(function (factory) {                                                                                 // 5
    if (typeof define === 'function' && define.amd) {                                                 // 6
        define(['moment'], factory); // AMD                                                           // 7
    } else if (typeof exports === 'object') {                                                         // 8
        module.exports = factory(require('../moment')); // Node                                       // 9
    } else {                                                                                          // 10
        factory((typeof global !== 'undefined' ? global : this).moment); // node or other global      // 11
    }                                                                                                 // 12
}(function (moment) {                                                                                 // 13
    function monthsCaseReplace(m, format) {                                                           // 14
        var months = {                                                                                // 15
            'nominative': 'იანვარი_თებერვალი_მარტი_აპრილი_მაისი_ივნისი_ივლისი_აგვისტო_სექტემბერი_ოქტომბერი_ნოემბერი_დეკემბერი'.split('_'),
            'accusative': 'იანვარს_თებერვალს_მარტს_აპრილის_მაისს_ივნისს_ივლისს_აგვისტს_სექტემბერს_ოქტომბერს_ნოემბერს_დეკემბერს'.split('_')
        },                                                                                            // 18
                                                                                                      // 19
        nounCase = (/D[oD] *MMMM?/).test(format) ?                                                    // 20
            'accusative' :                                                                            // 21
            'nominative';                                                                             // 22
                                                                                                      // 23
        return months[nounCase][m.month()];                                                           // 24
    }                                                                                                 // 25
                                                                                                      // 26
    function weekdaysCaseReplace(m, format) {                                                         // 27
        var weekdays = {                                                                              // 28
            'nominative': 'კვირა_ორშაბათი_სამშაბათი_ოთხშაბათი_ხუთშაბათი_პარასკევი_შაბათი'.split('_'), // 29
            'accusative': 'კვირას_ორშაბათს_სამშაბათს_ოთხშაბათს_ხუთშაბათს_პარასკევს_შაბათს'.split('_') // 30
        },                                                                                            // 31
                                                                                                      // 32
        nounCase = (/(წინა|შემდეგ)/).test(format) ?                                                   // 33
            'accusative' :                                                                            // 34
            'nominative';                                                                             // 35
                                                                                                      // 36
        return weekdays[nounCase][m.day()];                                                           // 37
    }                                                                                                 // 38
                                                                                                      // 39
    return moment.defineLocale('ka', {                                                                // 40
        months : monthsCaseReplace,                                                                   // 41
        monthsShort : 'იან_თებ_მარ_აპრ_მაი_ივნ_ივლ_აგვ_სექ_ოქტ_ნოე_დეკ'.split('_'),                   // 42
        weekdays : weekdaysCaseReplace,                                                               // 43
        weekdaysShort : 'კვი_ორშ_სამ_ოთხ_ხუთ_პარ_შაბ'.split('_'),                                     // 44
        weekdaysMin : 'კვ_ორ_სა_ოთ_ხუ_პა_შა'.split('_'),                                              // 45
        longDateFormat : {                                                                            // 46
            LT : 'h:mm A',                                                                            // 47
            LTS : 'h:mm:ss A',                                                                        // 48
            L : 'DD/MM/YYYY',                                                                         // 49
            LL : 'D MMMM YYYY',                                                                       // 50
            LLL : 'D MMMM YYYY LT',                                                                   // 51
            LLLL : 'dddd, D MMMM YYYY LT'                                                             // 52
        },                                                                                            // 53
        calendar : {                                                                                  // 54
            sameDay : '[დღეს] LT[-ზე]',                                                               // 55
            nextDay : '[ხვალ] LT[-ზე]',                                                               // 56
            lastDay : '[გუშინ] LT[-ზე]',                                                              // 57
            nextWeek : '[შემდეგ] dddd LT[-ზე]',                                                       // 58
            lastWeek : '[წინა] dddd LT-ზე',                                                           // 59
            sameElse : 'L'                                                                            // 60
        },                                                                                            // 61
        relativeTime : {                                                                              // 62
            future : function (s) {                                                                   // 63
                return (/(წამი|წუთი|საათი|წელი)/).test(s) ?                                           // 64
                    s.replace(/ი$/, 'ში') :                                                           // 65
                    s + 'ში';                                                                         // 66
            },                                                                                        // 67
            past : function (s) {                                                                     // 68
                if ((/(წამი|წუთი|საათი|დღე|თვე)/).test(s)) {                                          // 69
                    return s.replace(/(ი|ე)$/, 'ის წინ');                                             // 70
                }                                                                                     // 71
                if ((/წელი/).test(s)) {                                                               // 72
                    return s.replace(/წელი$/, 'წლის წინ');                                            // 73
                }                                                                                     // 74
            },                                                                                        // 75
            s : 'რამდენიმე წამი',                                                                     // 76
            m : 'წუთი',                                                                               // 77
            mm : '%d წუთი',                                                                           // 78
            h : 'საათი',                                                                              // 79
            hh : '%d საათი',                                                                          // 80
            d : 'დღე',                                                                                // 81
            dd : '%d დღე',                                                                            // 82
            M : 'თვე',                                                                                // 83
            MM : '%d თვე',                                                                            // 84
            y : 'წელი',                                                                               // 85
            yy : '%d წელი'                                                                            // 86
        },                                                                                            // 87
        ordinalParse: /0|1-ლი|მე-\d{1,2}|\d{1,2}-ე/,                                                  // 88
        ordinal : function (number) {                                                                 // 89
            if (number === 0) {                                                                       // 90
                return number;                                                                        // 91
            }                                                                                         // 92
                                                                                                      // 93
            if (number === 1) {                                                                       // 94
                return number + '-ლი';                                                                // 95
            }                                                                                         // 96
                                                                                                      // 97
            if ((number < 20) || (number <= 100 && (number % 20 === 0)) || (number % 100 === 0)) {    // 98
                return 'მე-' + number;                                                                // 99
            }                                                                                         // 100
                                                                                                      // 101
            return number + '-ე';                                                                     // 102
        },                                                                                            // 103
        week : {                                                                                      // 104
            dow : 1,                                                                                  // 105
            doy : 7                                                                                   // 106
        }                                                                                             // 107
    });                                                                                               // 108
}));                                                                                                  // 109
                                                                                                      // 110
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rzymek:moment-locale-ka'] = {};

})();

var require = meteorInstall({"collections":{"collections.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// collections/collections.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
//The Collections                                                                                                 // 1
Course = new Mongo.Collection('course');                                                                          // 2
CourseReview = new Mongo.Collection('courseReview');                                                              // 3
Internship = new Mongo.Collection('internship');                                                                  // 4
InternReview = new Mongo.Collection('internReview');                                                              // 5
ResHall = new Mongo.Collection('resHall');                                                                        // 6
ResReview = new Mongo.Collection('resReview');                                                                    // 7
Dining = new Mongo.Collection('dining');                                                                          // 8
DiningReview = new Mongo.Collection('diningReview');                                                              // 9
Club = new Mongo.Collection('club');                                                                              // 10
ClubReview = new Mongo.Collection('clubReview');                                                                  // 11
Departments = new Meteor.Collection('departments');                                                               // 12
Courses = new Meteor.Collection('courses'); //Schemas                                                             // 13
                                                                                                                  //
Course.schema = new SimpleSchema({                                                                                // 19
    Title: {                                                                                                      // 20
        type: String                                                                                              // 20
    },                                                                                                            // 20
    Number: {                                                                                                     // 21
        type: Number                                                                                              // 21
    },                                                                                                            // 21
    Abbreviation: {                                                                                               // 22
        type: String                                                                                              // 22
    },                                                                                                            // 22
    AvgWorkloadRating: {                                                                                          // 23
        type: Number                                                                                              // 23
    },                                                                                                            // 23
    AvgDifficultyRating: {                                                                                        // 24
        type: Number                                                                                              // 24
    },                                                                                                            // 24
    AvgUtilityRating: {                                                                                           // 25
        type: Number                                                                                              // 25
    }                                                                                                             // 25
});                                                                                                               // 19
CourseReview.schema = new SimpleSchema({                                                                          // 28
    course: {                                                                                                     // 29
        type: Meteor.Collection.ObjectID                                                                          // 29
    },                                                                                                            // 29
    userId: {                                                                                                     // 30
        type: Meteor.Collection.ObjectID                                                                          // 30
    },                                                                                                            // 30
    date: {                                                                                                       // 31
        type: Date                                                                                                // 31
    },                                                                                                            // 31
    review: {                                                                                                     // 32
        type: String                                                                                              // 32
    },                                                                                                            // 32
    difficultyRating: {                                                                                           // 33
        type: Number                                                                                              // 33
    },                                                                                                            // 33
    workloadRating: {                                                                                             // 34
        type: Number                                                                                              // 34
    },                                                                                                            // 34
    utilityRating: {                                                                                              // 35
        type: Number                                                                                              // 35
    }                                                                                                             // 35
});                                                                                                               // 28
Internship.schema = new SimpleSchema({                                                                            // 38
    name: {                                                                                                       // 39
        type: String                                                                                              // 39
    },                                                                                                            // 39
    avgInterviewRating: {                                                                                         // 40
        type: Number                                                                                              // 40
    },                                                                                                            // 40
    avgDifficultyRating: {                                                                                        // 41
        type: Number                                                                                              // 41
    },                                                                                                            // 41
    avgUtilityRating: {                                                                                           // 42
        type: Number                                                                                              // 42
    }                                                                                                             // 42
});                                                                                                               // 38
InternReview.schema = new SimpleSchema({                                                                          // 45
    internship: {                                                                                                 // 46
        type: Meteor.Collection.ObjectID                                                                          // 46
    },                                                                                                            // 46
    userId: {                                                                                                     // 47
        type: Meteor.Collection.ObjectID                                                                          // 47
    },                                                                                                            // 47
    date: {                                                                                                       // 48
        type: Date                                                                                                // 48
    },                                                                                                            // 48
    review: {                                                                                                     // 49
        type: String                                                                                              // 49
    },                                                                                                            // 49
    interviewRating: {                                                                                            // 50
        type: Number                                                                                              // 50
    },                                                                                                            // 50
    workloadRating: {                                                                                             // 51
        type: Number                                                                                              // 51
    },                                                                                                            // 51
    utilityRating: {                                                                                              // 52
        type: Number                                                                                              // 52
    }                                                                                                             // 52
});                                                                                                               // 45
ResHall.schema = new SimpleSchema({                                                                               // 55
    name: {                                                                                                       // 56
        type: String                                                                                              // 56
    },                                                                                                            // 56
    location: {                                                                                                   // 57
        type: String                                                                                              // 57
    },                                                                                                            // 57
    avgStarRating: {                                                                                              // 58
        type: Number                                                                                              // 58
    }                                                                                                             // 58
});                                                                                                               // 55
ResReview.schema = new SimpleSchema({                                                                             // 61
    resHall: {                                                                                                    // 62
        type: Meteor.Collection.ObjectID                                                                          // 62
    },                                                                                                            // 62
    userId: {                                                                                                     // 63
        type: Meteor.Collection.ObjectID                                                                          // 63
    },                                                                                                            // 63
    date: {                                                                                                       // 64
        type: Date                                                                                                // 64
    },                                                                                                            // 64
    review: {                                                                                                     // 65
        type: String                                                                                              // 65
    },                                                                                                            // 65
    starRating: {                                                                                                 // 66
        type: Number                                                                                              // 66
    }                                                                                                             // 66
});                                                                                                               // 61
Club.schema = new SimpleSchema({                                                                                  // 69
    name: {                                                                                                       // 70
        type: String                                                                                              // 70
    },                                                                                                            // 70
    avgTimeRating: {                                                                                              // 71
        type: Number                                                                                              // 71
    },                                                                                                            // 71
    avgUtilRating: {                                                                                              // 72
        type: Number                                                                                              // 72
    }                                                                                                             // 72
});                                                                                                               // 69
ClubReview.schema = new SimpleSchema({                                                                            // 75
    club: {                                                                                                       // 76
        type: Meteor.Collection.ObjectID                                                                          // 76
    },                                                                                                            // 76
    userId: {                                                                                                     // 77
        type: Meteor.Collection.ObjectID                                                                          // 77
    },                                                                                                            // 77
    date: {                                                                                                       // 78
        type: Date                                                                                                // 78
    },                                                                                                            // 78
    review: {                                                                                                     // 79
        type: String                                                                                              // 79
    },                                                                                                            // 79
    timeRating: {                                                                                                 // 80
        type: Number                                                                                              // 80
    },                                                                                                            // 80
    utilityRating: {                                                                                              // 81
        type: Number                                                                                              // 81
    }                                                                                                             // 81
});                                                                                                               // 75
Dining.schema = new SimpleSchema({                                                                                // 84
    name: {                                                                                                       // 85
        type: String                                                                                              // 85
    },                                                                                                            // 85
    location: {                                                                                                   // 86
        type: String                                                                                              // 86
    },                                                                                                            // 86
    avgStarRating: {                                                                                              // 87
        type: Number                                                                                              // 87
    },                                                                                                            // 87
    avgFoodQualityRating: {                                                                                       // 88
        type: Number                                                                                              // 88
    },                                                                                                            // 88
    avgHealthRating: {                                                                                            // 89
        type: Number                                                                                              // 89
    }                                                                                                             // 89
});                                                                                                               // 84
DiningReview.schema = new SimpleSchema({                                                                          // 92
    diningId: {                                                                                                   // 93
        type: Meteor.Collection.ObjectID                                                                          // 93
    },                                                                                                            // 93
    userId: {                                                                                                     // 94
        type: Meteor.Collection.ObjectID                                                                          // 94
    },                                                                                                            // 94
    date: {                                                                                                       // 95
        type: Date                                                                                                // 95
    },                                                                                                            // 95
    review: {                                                                                                     // 96
        type: String                                                                                              // 96
    },                                                                                                            // 96
    foodQualityRating: {                                                                                          // 97
        type: Number                                                                                              // 97
    },                                                                                                            // 97
    healthRating: {                                                                                               // 98
        type: Number                                                                                              // 98
    }                                                                                                             // 98
});                                                                                                               // 92
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"maybe.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/maybe.js                                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**                                                                                                               // 1
 * Created by Brad on 3/1/2017.                                                                                   //
 */Accounts.config({                                                                                              //
  restrictCreationByEmailDomain: 'purdue.edu'                                                                     // 5
});                                                                                                               // 4
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/main.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Meteor = void 0;                                                                                              // 1
module.import('meteor/meteor', {                                                                                  // 1
    "Meteor": function (v) {                                                                                      // 1
        Meteor = v;                                                                                               // 1
    }                                                                                                             // 1
}, 0);                                                                                                            // 1
Meteor.startup(function () {                                                                                      // 3
    // code to run on server at startup                                                                           // 4
    process.env.MAIL_URL = "smtp://postmaster@pathfynder.ltd:cookies@smtp.mailgun.org:587";                       // 5
    console.log(process.env);                                                                                     // 6
                                                                                                                  //
    Accounts.urls.verifyEmail = function (token) {                                                                // 7
        return Meteor.absoluteUrl('verify-email/' + token);                                                       // 8
    };                                                                                                            // 9
                                                                                                                  //
    Accounts.emailTemplates.resetPassword.text = function (user, url) {                                           // 10
        var token = url.substring(url.lastIndexOf('/') + 1, url.length);                                          // 11
        var newUrl = Meteor.absoluteUrl('reset-password/' + token);                                               // 12
        var str = 'Hello,\n';                                                                                     // 13
        str += 'To reset your password, please click the following link...\n';                                    // 14
        str += newUrl;                                                                                            // 15
        return str;                                                                                               // 16
    };                                                                                                            // 17
                                                                                                                  //
    Accounts.emailTemplates.resetPassword.from = function () {                                                    // 18
        // Overrides value set in Accounts.emailTemplates.from when resetting passwords                           // 19
        return "PathFynder Support <no-reply@pathfynder.ltd>";                                                    // 20
    };                                                                                                            // 21
                                                                                                                  //
    Accounts.emailTemplates.verifyEmail.from = function () {                                                      // 22
        // Overrides value set in Accounts.emailTemplates.from when resetting passwords                           // 23
        return "PathFynder Support <no-reply@pathfynder.ltd>";                                                    // 24
    };                                                                                                            // 25
                                                                                                                  //
    Accounts.emailTemplates.verifyEmail.subject = function () {                                                   // 26
        return "Verification Email for PathFynder";                                                               // 27
    };                                                                                                            // 28
                                                                                                                  //
    Accounts.emailTemplates.resetPassword.subject = function () {                                                 // 29
        return "Reset Password for PathFynder";                                                                   // 30
    };                                                                                                            // 31
}); //Accounts.urls.verifyEmail = function (token) {                                                              // 33
//   return Meteor.absoluteUrl('verify-email/' + token);                                                          // 35
//}                                                                                                               // 36
//Accounts.urls.resetPassword = function(token) {                                                                 // 37
//    return Meteor.absoluteUrl('reset-password/' + token);                                                       // 38
//};                                                                                                              // 39
                                                                                                                  //
Meteor.methods({                                                                                                  // 40
    serverVerifyEmail: function (email, userId, callback) {                                                       // 41
        console.log("Email to verify:" + email + " | userId: " + userId); // this needs to be done on the server.
                                                                                                                  //
        Accounts.sendVerificationEmail(userId, email);                                                            // 44
                                                                                                                  //
        if (typeof callback !== 'undefined') {                                                                    // 45
            callback();                                                                                           // 46
        }                                                                                                         // 47
    },                                                                                                            // 48
    checkEmailVerification: function (email) {                                                                    // 49
        var found_user = Meteor.users.findOne({                                                                   // 50
            'emails.address': email                                                                               // 50
        });                                                                                                       // 50
                                                                                                                  //
        if (found_user) {                                                                                         // 51
            if (found_user.emails[0].verified == true) {                                                          // 52
                return "verified";                                                                                // 53
            } else {                                                                                              // 54
                return "unverified";                                                                              // 55
            }                                                                                                     // 56
        } else {                                                                                                  // 57
            return "notfound";                                                                                    // 58
        }                                                                                                         // 59
    },                                                                                                            // 60
    remove: function (userId, error) {                                                                            // 61
        console.log(userId);                                                                                      // 62
                                                                                                                  //
        try {                                                                                                     // 63
            Meteor.users.remove(userId);                                                                          // 64
        } catch (e) {                                                                                             // 65
            console.log('Something went wrong trying to delete account');                                         // 66
        }                                                                                                         // 67
    },                                                                                                            // 68
    setPassword: function (userId, newPassword, error) {                                                          // 69
        console.log(newPassword);                                                                                 // 70
                                                                                                                  //
        try {                                                                                                     // 71
            Accounts.setPassword(userId, newPassword);                                                            // 72
        } catch (e) {                                                                                             // 73
            console.log('Something went wrong trying to change password.');                                       // 74
        }                                                                                                         // 75
    }                                                                                                             // 76
});                                                                                                               // 40
Accounts.onCreateUser(function (options, user) {                                                                  // 78
    if (options.profile) {                                                                                        // 79
        user.profile = options.profile;                                                                           // 80
    } else {                                                                                                      // 81
        user.profile = {};                                                                                        // 82
    }                                                                                                             // 83
                                                                                                                  //
    user.profile.username = '';                                                                                   // 84
    user.profile.university = '';                                                                                 // 85
    user.profile.gradDate = '';                                                                                   // 86
    user.profile.major = '';                                                                                      // 87
    user.profile.majorBool = false;                                                                               // 88
    user.profile.usernameBool = false;                                                                            // 89
    user.profile.gradDateBool = false;                                                                            // 90
    return user;                                                                                                  // 91
});                                                                                                               // 92
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./collections/collections.js");
require("./server/maybe.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
